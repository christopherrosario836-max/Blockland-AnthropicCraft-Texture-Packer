'use strict';
/* ---------- constants & block table ---------- */
const CS = 16, H = 80, SEA = 24;
const B = { IRON: 13, TABLE: 14, FURNACE: 15, ANVIL: 16, AIR: 0, GRASS: 1, DIRT: 2, STONE: 3, SAND: 4, LOG: 5, LEAVES: 6, PLANKS: 7, COBBLE: 8, WATER: 9, COAL: 10, BEDROCK: 11, GLASS: 12 };
const BNAME = ['Air', 'Grass', 'Dirt', 'Stone', 'Sand', 'Log', 'Leaves', 'Planks', 'Cobblestone', 'Water', 'Coal Ore', 'Bedrock', 'Glass', 'Iron Ore', 'Crafting Table', 'Furnace', 'Anvil'];
const OPAQUE = new Uint8Array(32), SOLID = new Uint8Array(32), SKYBLOCK = new Uint8Array(32), HARD = new Float32Array(32);
[1, 2, 3, 4, 5, 7, 8, 10, 11, 13, 14, 15, 16].forEach(i => OPAQUE[i] = 1);
for (let i = 1; i < 17; i++) { if (i !== B.WATER) SOLID[i] = 1; if (i !== B.WATER && i !== B.GLASS) SKYBLOCK[i] = 1; }
HARD[1] = 0.6; HARD[2] = 0.5; HARD[3] = 2.0; HARD[4] = 0.5; HARD[5] = 1.1; HARD[6] = 0.25; HARD[7] = 1.0; HARD[8] = 2.2; HARD[10] = 2.6; HARD[12] = 0.4; HARD[13] = 3.0; HARD[14] = 1.2; HARD[15] = 2.5; HARD[16] = 3.2;
/* atlas tiles: 0 grass top, 1 grass side, 2 dirt, 3 stone, 4 sand, 5 log side, 6 log top, 7 leaves, 8 planks, 9 cobble, 10 water, 11 coal, 12 bedrock, 13 glass */
function tileFor(id, face) {
  switch (id) {
    case B.GRASS: return face === 2 ? 0 : face === 3 ? 2 : 1;
    case B.DIRT: return 2; case B.STONE: return 3; case B.SAND: return 4;
    case B.LOG: return face === 2 || face === 3 ? 6 : 5;
    case B.LEAVES: return 7; case B.PLANKS: return 8; case B.COBBLE: return 9;
    case B.WATER: return 10; case B.COAL: return 11; case B.BEDROCK: return 12; case B.GLASS: return 13;
    case B.IRON: return 15; case B.TABLE: return face === 2 ? 16 : face === 3 ? 8 : 17; case B.FURNACE: return face === 2 || face === 3 ? 20 : 19; case B.ANVIL: return 21;
  }
  return 3;
}
const ICON = [0, 0, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 15, 17, 19, 21];
const DROP = (id) => id === B.GRASS ? B.DIRT : id === B.STONE ? B.COBBLE : id === B.LEAVES ? 0 : id === B.BEDROCK ? 0 : id === B.COAL ? 22 : id;

