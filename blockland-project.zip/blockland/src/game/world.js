/* ---------- terrain ---------- */
function terrH(x, z) {
  const S = v => (v - 0.5) * 2.5 + 0.5;
  const c = S(fbm2(x * 0.004 + 100, z * 0.004 - 50, 2));
  const hill = S(fbm2(x * 0.02, z * 0.02, 4));
  let h = 8 + c * 30 + hill * 16;
  const m = Math.max(0, S(fbm2(x * 0.008 - 300, z * 0.008 + 300, 3)) - 0.7);
  h += m * 60;
  return Math.floor(Math.max(3, Math.min(h, 62)));
}
function isDesert(x, z, h) { return h > SEA + 1 && fbm2(x * 0.006 + 900, z * 0.006 - 900, 3) < 0.37; }
function caveAt(x, y, z) {
  const v = vnoise3(x * 0.06, y * 0.09, z * 0.06, SEED + 5) * 0.65 + vnoise3(x * 0.13, y * 0.17, z * 0.13, SEED + 9) * 0.35;
  return v > 0.72;
}
function treeAt(x, z) {
  const f = fbm2(x * 0.012 + 700, z * 0.012 - 700, 2);
  const dens = 0.004 + Math.max(0, f - 0.38) * 0.22;
  if (hash2(x, z, SEED + 71) >= dens) return 0;
  const h = terrH(x, z);
  if (h <= SEA + 1 || h >= 48 || isDesert(x, z, h)) return 0;
  return h;
}

/* biome colour blend: 0 = dry, 1 = lush */
function biomeT(x, z) { const n = fbm2(x * 0.007 + 500, z * 0.007 - 500, 2); return Math.max(0, Math.min(1, (n - 0.36) / 0.28)); }

/* ---------- chunk storage ---------- */
const chunks = new Map();
const edits = new Map(); // chunkKey -> Map(idx -> id)
const ck = (cx, cz) => (cx + 32768) * 65536 + (cz + 32768);
const bidx = (x, y, z) => (y * 16 + z) * 16 + x;

function genChunk(cx, cz) {
  const blocks = new Uint8Array(CS * CS * H), top = new Uint8Array(256);
  const x0 = cx * 16, z0 = cz * 16;
  for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const wx = x0 + lx, wz = z0 + lz, h = terrH(wx, wz), sandy = h <= SEA + 1 || isDesert(wx, wz, h);
    for (let y = 0; y <= h; y++) {
      let id;
      if (y === 0) id = B.BEDROCK;
      else if (y <= h - 4) { id = B.STONE; if (y < 40 && hash3(wx, y, wz, SEED + 13) < 0.012) id = B.COAL; else if (y < 32 && hash3(wx, y, wz, SEED + 17) < 0.010) id = B.IRON; }
      else if (sandy) id = B.SAND;
      else if (h >= 52) id = B.STONE;
      else id = y === h ? B.GRASS : B.DIRT;
      if (y > 3 && y < h - 3 && caveAt(wx, y, wz)) id = B.AIR;
      blocks[bidx(lx, y, lz)] = id;
    }
    for (let y = h + 1; y <= SEA; y++) blocks[bidx(lx, y, lz)] = B.WATER;
  }
  // trees (include a margin so canopies cross chunk borders)
  for (let tz = z0 - 2; tz < z0 + 18; tz++) for (let tx = x0 - 2; tx < x0 + 18; tx++) {
    const gh = treeAt(tx, tz); if (!gh) continue;
    const th = 4 + Math.floor(hash2(tx, tz, SEED + 33) * 3);
    const put = (px, py, pz, id, force) => {
      const lx = px - x0, lz = pz - z0; if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || py >= H) return;
      const i = bidx(lx, py, lz), cur = blocks[i];
      if (force ? (cur === 0 || cur === B.LEAVES) : cur === 0) blocks[i] = id;
    };
    for (let dy = 1; dy <= th; dy++) put(tx, gh + dy, tz, B.LOG, true);
    for (let dy = th - 2; dy <= th + 1; dy++) {
      const r = dy >= th ? 1 : 2;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (dx === 0 && dz === 0 && dy <= th) continue;
        const corner = Math.abs(dx) === r && Math.abs(dz) === r;
        if (corner && (r === 1 || hash3(tx + dx, gh + dy, tz + dz, SEED + 44) < 0.5)) continue;
        put(tx + dx, gh + dy, tz + dz, B.LEAVES, false);
      }
    }
  }
  const ed = edits.get(ck(cx, cz));
  if (ed) ed.forEach((id, i) => { blocks[i] = id; });
  const c = { cx, cz, blocks, top, dirty: true, mesh: null, state: 0 };
  recomputeTop(c);
  return c;
}
function recomputeTop(c) {
  for (let i = 0; i < 256; i++) {
    let y = H - 1; while (y >= 0 && !SKYBLOCK[c.blocks[i + y * 256]]) y--;
    c.top[i] = y < 0 ? 0 : y;
  }
}
function getBlock(x, y, z) {
  if (y < 0) return B.BEDROCK; if (y >= H) return 0;
  const c = chunks.get(ck(x >> 4, z >> 4));
  if (!c) return B.STONE;
  return c.blocks[bidx(x & 15, y, z & 15)];
}
function getTop(x, z) {
  const c = chunks.get(ck(x >> 4, z >> 4)); if (!c) return 0;
  return c.top[(z & 15) * 16 + (x & 15)];
}
function setBlock(x, y, z, id) {
  if (y < 0 || y >= H) return;
  const cx = x >> 4, cz = z >> 4, k = ck(cx, cz), c = chunks.get(k); if (!c) return;
  const lx = x & 15, lz = z & 15, i = bidx(lx, y, lz);
  c.blocks[i] = id;
  let m = edits.get(k); if (!m) { m = new Map(); edits.set(k, m); }
  m.set(i, id);
  let t = H - 1; while (t >= 0 && !SKYBLOCK[c.blocks[lz * 16 + lx + t * 256]]) t--;
  c.top[lz * 16 + lx] = t < 0 ? 0 : t;
  c.dirty = true; c.now = true;
  const nb = (dx, dz) => { const n = chunks.get(ck(cx + dx, cz + dz)); if (n) { n.dirty = true; n.now = true; } };
  if (lx === 0) nb(-1, 0); if (lx === 15) nb(1, 0); if (lz === 0) nb(0, -1); if (lz === 15) nb(0, 1);
}

/* ---------- meshing (pure: returns typed arrays) ---------- */
const FACE = [
  { d: [1, 0, 0], c: [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]], s: 0.68 },
  { d: [-1, 0, 0], c: [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]], s: 0.68 },
  { d: [0, 1, 0], c: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], s: 1.0 },
  { d: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], s: 0.5 },
  { d: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], s: 0.84 },
  { d: [0, 0, -1], c: [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]], s: 0.84 },
];
const UVC = [[0, 1], [1, 1], [1, 0], [0, 0]];
let scratchO = new Float32Array(1 << 18), scratchW = new Float32Array(1 << 16);
function ensure(arr, need) { if (need <= arr.length) return arr; const n = new Float32Array(Math.max(need, arr.length * 2)); n.set(arr); return n; }

function buildMeshData(c) {
  const bl = c.blocks, x0 = c.cx * 16, z0 = c.cz * 16, tcol = new Float32Array(256);
  for (let i = 0; i < 256; i++) tcol[i] = biomeT(x0 + (i & 15), z0 + (i >> 4));
  let no = 0, nw = 0;
  const E = 0.002;
  for (let y = 0; y < H; y++) for (let lz = 0; lz < 16; lz++) for (let lx = 0; lx < 16; lx++) {
    const id = bl[(y * 16 + lz) * 16 + lx]; if (!id) continue;
    const isW = id === B.WATER;
    for (let f = 0; f < 6; f++) {
      const F = FACE[f], nx = lx + F.d[0], ny = y + F.d[1], nz = lz + F.d[2];
      let n;
      if (ny < 0) n = B.BEDROCK; else if (ny >= H) n = 0;
      else if (nx >= 0 && nx < 16 && nz >= 0 && nz < 16) n = bl[(ny * 16 + nz) * 16 + nx];
      else n = getBlock(x0 + nx, ny, z0 + nz);
      let vis;
      if (isW) vis = n !== B.WATER && !OPAQUE[n];
      else if (id === B.LEAVES) vis = n !== B.LEAVES && !OPAQUE[n];
      else if (id === B.GLASS) vis = n !== B.GLASS && !OPAQUE[n];
      else vis = !OPAQUE[n];
      if (!vis) continue;
      let top;
      if (nx >= 0 && nx < 16 && nz >= 0 && nz < 16) top = c.top[nz * 16 + nx]; else top = getTop(x0 + nx, z0 + nz);
      const sky = ny > top ? 2 : 0, shade = F.s + sky;
      let ytop = 1;
      if (isW && (y + 1 >= H || bl[((y + 1) * 16 + lz) * 16 + lx] !== B.WATER)) ytop = 0.88;
      const bt = tcol[lz * 16 + lx];
      // layers: [tile, tint, push-out]
      let layers;
      if (id === B.GRASS) layers = f === 2 ? [[0, 1 + bt, 0]] : f === 3 ? [[2, 0, 0]] : [[1, 0, 0], [25, 1 + bt, 0.004]];
      else if (id === B.LEAVES) layers = [[7, 3 + bt, 0]];
      else layers = [[tileFor(id, f), 0, 0]];
      for (const L of layers) {
        const tile = L[0], tu = (tile % 16) / 16, tv = ((tile / 16) | 0) / 16, ts = 1 / 16;
        let arr, o;
        if (isW) { scratchW = ensure(scratchW, nw + 42); arr = scratchW; o = nw; } else { scratchO = ensure(scratchO, no + 42); arr = scratchO; o = no; }
        const put = (k) => {
          const cc = F.c[k], uv = UVC[k];
          arr[o++] = lx + cc[0] + F.d[0] * L[2]; arr[o++] = y + (cc[1] ? ytop : 0) + F.d[1] * L[2]; arr[o++] = lz + cc[2] + F.d[2] * L[2];
          arr[o++] = tu + (uv[0] ? ts - E * ts : E * ts); arr[o++] = tv + (uv[1] ? ts - E * ts : E * ts); arr[o++] = shade; arr[o++] = L[1];
        };
        put(0); put(1); put(2); put(0); put(2); put(3);
        if (isW) nw = o; else no = o;
      }
    }
  }
  return { o: scratchO.slice(0, no), w: scratchW.slice(0, nw) };
}

/* ---------- ray cast through voxels ---------- */
function raycast(ox, oy, oz, dx, dy, dz, maxD) {
  let x = Math.floor(ox), y = Math.floor(oy), z = Math.floor(oz);
  const sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
  const tdx = dx !== 0 ? Math.abs(1 / dx) : Infinity, tdy = dy !== 0 ? Math.abs(1 / dy) : Infinity, tdz = dz !== 0 ? Math.abs(1 / dz) : Infinity;
  let tmx = dx !== 0 ? ((dx > 0 ? x + 1 - ox : ox - x)) * tdx : Infinity;
  let tmy = dy !== 0 ? ((dy > 0 ? y + 1 - oy : oy - y)) * tdy : Infinity;
  let tmz = dz !== 0 ? ((dz > 0 ? z + 1 - oz : oz - z)) * tdz : Infinity;
  let nx = 0, ny = 0, nz = 0, t = 0;
  while (t <= maxD) {
    const id = getBlock(x, y, z);
    if (id && id !== B.WATER) return { x, y, z, nx, ny, nz, id, t };
    if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; nx = -sx; ny = 0; nz = 0; }
    else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; nx = 0; ny = -sy; nz = 0; }
    else { z += sz; t = tmz; tmz += tdz; nx = 0; ny = 0; nz = -sz; }
  }
  return null;
}
function findSpawn() {
  for (let r = 0; r < 400; r += 6) for (let a = 0; a < 8; a++) {
    const x = Math.round(Math.cos(a * 0.785) * r), z = Math.round(Math.sin(a * 0.785) * r), h = terrH(x, z);
    if (h > SEA + 2 && h < 44 && !isDesert(x, z, h)) return { x: x + 0.5, y: h + 1, z: z + 0.5 };
  }
  return { x: 0.5, y: terrH(0, 0) + 2, z: 0.5 };
}
