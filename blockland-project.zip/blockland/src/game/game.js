/* ---------- setup ---------- */
const $ = id => document.getElementById(id);
const canvas = $('c');
const TOUCH = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
if (TOUCH) { document.body.classList.add('touch'); $('keysDesk').style.display = 'none'; $('keysTouch').style.display = 'grid'; }
const atlasCv = makeAtlas();
const st = document.createElement('style'); document.head.appendChild(st);
let curAtlas = atlasCv;
const hexRGB = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255);
const tintCfg = { grass: TINT_DEFAULT.grass[0], foliage: TINT_DEFAULT.foliage[0] };
try { const t = JSON.parse(localStorage.getItem('blockland-tint') || 'null'); if (t && t.grass && t.foliage) { tintCfg.grass = t.grass; tintCfg.foliage = t.foliage; } } catch (e) { }
function applyTints() {
  const dry = (h, k) => { const l = hexRGB(h), d = hexRGB(TINT_DEFAULT[k][1]), dl = hexRGB(TINT_DEFAULT[k][0]); return l.map((v, i) => Math.max(0, Math.min(1, v + (d[i] - dl[i])))); };
  const g = hexRGB(tintCfg.grass), f = hexRGB(tintCfg.foliage);
  R.tintArr = new Float32Array([...dry(tintCfg.grass, 'grass'), ...g, ...dry(tintCfg.foliage, 'foliage'), ...f]);
  const cv = document.createElement('canvas'); cv.width = cv.height = 256; const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(curAtlas, 0, 0);
  for (const [t, col] of [[0, tintCfg.grass], [7, tintCfg.foliage]]) {
    const dx = (t % 16) * 16, dy = Math.floor(t / 16) * 16, tc = document.createElement('canvas'); tc.width = tc.height = 16; const y = tc.getContext('2d');
    y.drawImage(curAtlas, dx, dy, 16, 16, 0, 0, 16, 16); y.globalCompositeOperation = 'multiply'; y.fillStyle = col; y.fillRect(0, 0, 16, 16); y.globalCompositeOperation = 'destination-in'; y.drawImage(curAtlas, dx, dy, 16, 16, 0, 0, 16, 16);
    x.clearRect(dx, dy, 16, 16); x.drawImage(tc, dx, dy);
  }
  st.textContent = '.ic{background-image:url(' + cv.toDataURL() + ')}';
}
let glOK = false;
try { glOK = initGL(canvas, atlasCv); } catch (e) { console.error(e); }
if (!glOK) { $('menuSub').textContent = 'This device does not support WebGL 2, which the game needs. Try a recent version of Chrome, Safari or Firefox.'; $('btnPlay').disabled = true; $('btnNew').disabled = true; }

const SAVE_KEY = 'blockland-save-v1';
const G = { playing: false, started: false, mode: 'survival', time: 0.08, rd: 5, hp: 20, sel: 0, fly: false, lockFailed: false };
const P = { x: 0.5, y: 40, z: 0.5, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0, ground: false, fall: 0, inWater: false, headWater: false, hurtT: 0 };
let inv = new Map(), hot = new Array(9).fill(0), spawn = { x: 0.5, y: 40, z: 0.5 };
let mobs = [], parts = [], extra = { mobs: [], hl: null, brk: 0, renderDist: 5, drawn: 0 };
let target = null, mobTarget = null, brkProg = 0, brkKey = '', needed = [], lastPC = '', fps = 0, fpsAcc = 0, fpsN = 0, showDbg = false, hudDirty = true, saveT = 0;

/* ---------- audio ---------- */
let actx = null;
function blip(f, d, type, vol, slide) {
  try {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    const t = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
    o.type = type || 'square'; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f * slide), t + d);
    g.gain.setValueAtTime(vol || 0.05, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + d + 0.02);
  } catch (e) { }
}
const sfx = { brk: () => blip(130, 0.12, 'sawtooth', 0.06, 0.5), put: () => blip(190, 0.08, 'square', 0.04, 0.7), hit: () => blip(240, 0.1, 'square', 0.05, 0.4), hurt: () => blip(160, 0.22, 'sawtooth', 0.08, 0.4), pop: () => blip(520, 0.1, 'triangle', 0.05, 1.6) };

/* ---------- ui helpers ---------- */
let toastT = 0;
function toast(msg) { const t = $('toast'); t.textContent = msg; t.style.opacity = 1; clearTimeout(toastT); toastT = setTimeout(() => t.style.opacity = 0, 1800); }
const itemTile = id => id < 20 ? ICON[id] : id === 20 ? 14 : id === 21 ? 22 : id === 22 ? 23 : id === 23 ? 24 : 28 + (id - 30);
function icon(id, cls) { const tile = itemTile(id); const d = document.createElement('div'); d.className = 'ic'; d.style.backgroundPosition = ((tile % 16) / 15 * 100) + '% ' + (((tile / 16) | 0) / 15 * 100) + '%'; return d; }
const TIERN = ['Wooden', 'Stone', 'Iron'], TYPEN = ['Pickaxe', 'Axe', 'Sword', 'Shovel'];
const ITEMNAME = id => id === 20 ? 'Raw Meat' : id === 21 ? 'Stick' : id === 22 ? 'Coal' : id === 23 ? 'Iron Ingot' : id >= 30 ? TIERN[(id - 30) % 3] + ' ' + TYPEN[((id - 30) / 3) | 0] : BNAME[id];
const TOOL = id => id >= 30 ? { type: ((id - 30) / 3) | 0, tier: (id - 30) % 3 } : null;
const DURMAX = [60, 132, 250], TMULT = [2.5, 4, 6], DMG = [[2, 3, 4], [3, 4, 5], [4, 5, 6], [2, 3, 4]];
const MATCH = { 0: [3, 8, 10, 13, 15, 16], 1: [5, 7, 14, 6], 3: [1, 2, 4] };
let dura = new Map();
function heldTool() { if (G.mode !== 'creative' && !(inv.get(hot[G.sel]) > 0)) return null; return TOOL(hot[G.sel]); }
function useTool() {
  if (G.mode === 'creative') return; const id = hot[G.sel]; if (!TOOL(id)) return;
  const left = (dura.has(id) ? dura.get(id) : DURMAX[(id - 30) % 3]) - 1;
  if (left <= 0) { dura.delete(id); takeItem(id); toast(ITEMNAME(id) + ' broke'); } else dura.set(id, left);
  hudDirty = true;
}
function buildHotbar() {
  const hb = $('hotbar'); hb.innerHTML = '';
  for (let i = 0; i < 9; i++) {
    const s = document.createElement('div'); s.className = 'slot' + (i === G.sel ? ' sel' : '');
    const id = hot[i];
    if (id) { s.appendChild(icon(id)); if (G.mode === 'survival') { const c = document.createElement('div'); c.className = 'cnt'; c.textContent = TOOL(id) ? '' : (inv.get(id) || 0); s.appendChild(c); if (TOOL(id) && dura.has(id)) { const f = dura.get(id) / DURMAX[(id - 30) % 3], b = document.createElement('div'); b.style.cssText = 'position:absolute;left:5px;right:5px;bottom:3px;height:3px;background:#000'; b.innerHTML = '<i style="display:block;height:100%;width:' + (f * 100) + '%;background:' + (f > 0.5 ? '#6bd13a' : f > 0.2 ? '#f2b94b' : '#e0523f') + '"></i>'; s.appendChild(b); } } }
    const pick = e => { e.preventDefault(); e.stopPropagation(); G.sel = i; hudDirty = true; showHeld(); };
    s.addEventListener('pointerdown', pick);
    hb.appendChild(s);
  }
  const h = $('hearts'); h.innerHTML = '';
  for (let i = 0; i < 10; i++) { const e = document.createElement('i'); e.textContent = '♥'; const v = G.hp - i * 2; e.className = v >= 2 ? 'on' : v === 1 ? 'half' : ''; h.appendChild(e); }
  h.style.display = G.mode === 'survival' ? 'flex' : 'none';
  hudDirty = false;
}
function showHeld() { const id = hot[G.sel]; if (id) toast(ITEMNAME(id)); }
function addItem(id, n) {
  if (G.mode === 'creative') return;
  inv.set(id, (inv.get(id) || 0) + n);
  if (hot.indexOf(id) < 0) { const e = hot.indexOf(0); if (e >= 0) hot[e] = id; }
  hudDirty = true;
}
function takeItem(id) {
  if (G.mode === 'creative') return true;
  const n = inv.get(id) || 0; if (n <= 0) return false;
  if (n === 1) { inv.delete(id); for (let i = 0; i < 9; i++) if (hot[i] === id) hot[i] = 0; } else inv.set(id, n - 1);
  hudDirty = true; return true;
}

/* ---------- panel: crafting + bag ---------- */
const RECIPES = [
  { out: [B.PLANKS, 4], need: [[B.LOG, 1]], st: 0 },
  { out: [21, 4], need: [[B.PLANKS, 2]], st: 0 },
  { out: [B.TABLE, 1], need: [[B.PLANKS, 4]], st: 0 },
  { out: [B.FURNACE, 1], need: [[B.COBBLE, 8]], st: 1 },
  { out: [B.ANVIL, 1], need: [[23, 5]], st: 1 },
  { out: [B.GLASS, 1], need: [[B.SAND, 1], [22, 1]], st: 2 },
  { out: [B.STONE, 1], need: [[B.COBBLE, 1], [22, 1]], st: 2 },
  { out: [23, 1], need: [[B.IRON, 1], [22, 1]], st: 2 },
];
[[B.PLANKS, 0], [B.COBBLE, 1], [23, 2]].forEach(([mat, tier]) => [[0, 3], [1, 3], [2, 2], [3, 1]].forEach(([type, n]) => RECIPES.push({ out: [30 + type * 3 + tier, 1], need: [[mat, n], [21, type === 2 ? 1 : 2]], st: 1 })));
const STN = ['', 'crafting table', 'furnace'];
function nearBlock(id) { const x0 = Math.floor(P.x), y0 = Math.floor(P.y), z0 = Math.floor(P.z); for (let y = y0 - 2; y <= y0 + 3; y++) for (let z = z0 - 4; z <= z0 + 4; z++) for (let x = x0 - 4; x <= x0 + 4; x++) if (getBlock(x, y, z) === id) return true; return false; }
function openPanel() {
  if (!G.playing) return;
  if (document.pointerLockElement) document.exitPointerLock();
  G.playing = false; $('panel').style.display = 'flex'; renderPanel();
}
function closePanel() { $('panel').style.display = 'none'; if (G.started) { G.playing = true; lockPointer(); } }
function renderPanel() {
  const body = $('panelBody'); body.innerHTML = ''; const surv = G.mode === 'survival';
  $('panelTitle').textContent = surv ? 'Crafting and Bag' : 'Block Bag';
  const note = document.createElement('p'); note.className = 'sub'; note.textContent = 'Tap a block to put it in the selected hotbar slot (slot ' + (G.sel + 1) + ').'; body.appendChild(note);
  if (surv) {
    for (const r of RECIPES) {
      const row = document.createElement('div'); row.className = 'recipe';
      row.appendChild(icon(r.out[0])); const stOk = r.st === 0 || G.mode === 'creative' || nearBlock(r.st === 1 ? B.TABLE : B.FURNACE);
      const t = document.createElement('div'); t.className = 't'; t.textContent = (r.out[1] > 1 ? r.out[1] + ' ' : '') + ITEMNAME(r.out[0]) + '  \u2190  ' + r.need.map(n => n[1] + ' ' + ITEMNAME(n[0])).join(' + ') + (r.st && !stOk ? '  (needs a ' + STN[r.st] + ' nearby)' : ''); row.appendChild(t);
      const b = document.createElement('button'); b.className = 'sm'; b.textContent = 'Craft';
      b.disabled = !stOk || !r.need.every(n => (inv.get(n[0]) || 0) >= n[1]);
      b.onclick = () => { for (const n of r.need) for (let k = 0; k < n[1]; k++) takeItem(n[0]); addItem(r.out[0], r.out[1]); sfx.pop(); renderPanel(); };
      row.appendChild(b); body.appendChild(row);
    }
  }
  const grid = document.createElement('div'); grid.className = 'pick';
  const list = surv ? [...inv.keys()].sort((a, b) => a - b) : [1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41];
  if (surv && !list.length) { const e = document.createElement('p'); e.className = 'sub'; e.textContent = 'Your bag is empty. Walk up to a tree and hold the mine button on its trunk.'; body.appendChild(e); }
  for (const id of list) {
    const s = document.createElement('div'); s.className = 'slot'; s.title = ITEMNAME(id); s.appendChild(icon(id));
    if (surv) { const c = document.createElement('div'); c.className = 'cnt'; c.textContent = inv.get(id); s.appendChild(c); }
    s.onclick = () => { const o = hot.indexOf(id); if (o >= 0) hot[o] = 0; hot[G.sel] = id; hudDirty = true; renderPanel(); };
    grid.appendChild(s);
  }
  body.appendChild(grid);
}
$('panelClose').onclick = closePanel;

/* ---------- world lifecycle ---------- */
function seedFrom(str) { if (!str) return Math.floor(Math.random() * 1e9); let h = 7; for (const ch of str) h = (Math.imul(h, 31) + ch.charCodeAt(0)) | 0; return Math.abs(h) % 1e9 + 1; }
function resetWorld(seed) {
  for (const c of chunks.values()) freeMesh(c);
  chunks.clear(); edits.clear(); SEED = seed; mobs = []; parts = []; lastPC = ''; needed = []; R.cloudKey = '';
}
function preload(cx0, cz0, r) {
  for (let cz = cz0 - r; cz <= cz0 + r; cz++) for (let cx = cx0 - r; cx <= cx0 + r; cx++) { const k = ck(cx, cz); if (!chunks.has(k)) chunks.set(k, genChunk(cx, cz)); }
  for (let cz = cz0 - r + 1; cz <= cz0 + r - 1; cz++) for (let cx = cx0 - r + 1; cx <= cx0 + r - 1; cx++) meshChunk(chunks.get(ck(cx, cz)));
}
function meshChunk(c) { if (!c) return; uploadMesh(c, buildMeshData(c)); c.dirty = false; c.now = false; }
function saveGame() {
  if (!G.started) return;
  try {
    const ed = []; edits.forEach((m, k) => ed.push([k, [...m]]));
    localStorage.setItem(SAVE_KEY, JSON.stringify({ seed: SEED, mode: G.mode, time: G.time, hp: G.hp, p: [P.x, P.y, P.z, P.yaw, P.pitch], spawn, inv: [...inv], dura: [...dura], hot, sel: G.sel, ed }));
    $('saveNote').textContent = 'World saved in this browser.';
  } catch (e) { $('saveNote').textContent = 'Saving is unavailable here, so this world will not be kept.'; }
}
function readSave() { try { const s = localStorage.getItem(SAVE_KEY); return s ? JSON.parse(s) : null; } catch (e) { return null; } }
function startGame(save, seedStr, mode) {
  $('loadMsg').style.display = 'block'; $('btnPlay').disabled = true;
  setTimeout(() => {
    if (save) {
      resetWorld(save.seed); G.mode = save.mode; G.time = save.time; G.hp = save.hp; spawn = save.spawn;
      P.x = save.p[0]; P.y = save.p[1]; P.z = save.p[2]; P.yaw = save.p[3]; P.pitch = save.p[4];
      inv = new Map(save.inv); dura = new Map(save.dura || []); hot = save.hot; G.sel = save.sel;
      for (const [k, arr] of save.ed) edits.set(k, new Map(arr));
    } else {
      resetWorld(seedFrom(seedStr)); G.mode = mode; G.time = 0.08; G.hp = 20; spawn = findSpawn();
      P.x = spawn.x; P.y = spawn.y; P.z = spawn.z; P.yaw = 0; P.pitch = 0; inv = new Map(); dura = new Map();
      hot = G.mode === 'creative' ? [1, 2, 3, 5, 7, 14, 15, 16, 32] : new Array(9).fill(0); G.sel = 0;
    }
    P.vx = P.vy = P.vz = 0; G.fly = false; P.fall = 0;
    preload(Math.floor(P.x / 16), Math.floor(P.z / 16), 3);
    if (!save) { // make sure we stand on solid ground
      let y = H - 1; while (y > 1 && !SOLID[getBlock(Math.floor(P.x), y, Math.floor(P.z))]) y--; P.y = y + 1.01; spawn.y = P.y;
    }
    G.started = true; G.playing = true; hudDirty = true;
    $('menu').style.display = 'none'; $('loadMsg').style.display = 'none'; $('btnPlay').disabled = false;
    $('btnPlay').textContent = 'Resume'; $('clock').style.display = 'block'; $('timeRow').style.display = 'flex';
    lockPointer(); saveGame();
  }, 30);
}
function pauseGame() {
  if (!G.started || !G.playing) return;
  G.playing = false; if (document.pointerLockElement) document.exitPointerLock();
  $('menu').style.display = 'flex'; saveGame(); keys.clear(); mine.held = false; mine.btn = false;
}
function resumeGame() { $('menu').style.display = 'none'; G.playing = true; lockPointer(); }
function lockPointer() {
  if (TOUCH || G.lockFailed) return;
  try { const p = canvas.requestPointerLock(); if (p && p.catch) p.catch(() => { G.lockFailed = true; }); } catch (e) { G.lockFailed = true; }
}
document.addEventListener('pointerlockerror', () => { G.lockFailed = true; });
document.addEventListener('pointerlockchange', () => { if (!document.pointerLockElement && G.playing && !TOUCH && !G.lockFailed) pauseGame(); });

/* ---------- input ---------- */
const keys = new Set(); const mine = { held: false, btn: false }; let lastSpace = 0;
const joy = { x: 0, y: 0, id: null, sprint: false }, tbtn = { jump: false, down: false };
window.addEventListener('keydown', e => {
  if (e.target && e.target.tagName === 'INPUT') return;
  if (e.code === 'F3') { e.preventDefault(); showDbg = !showDbg; $('debug').style.display = showDbg ? 'block' : 'none'; return; }
  if (!G.playing) { if ((e.code === 'KeyE' || e.code === 'Escape') && $('panel').style.display === 'flex') closePanel(); return; }
  if (e.repeat) { if (e.code === 'Space') e.preventDefault(); return; }
  keys.add(e.code);
  if (e.code === 'Space') { e.preventDefault(); const n = performance.now(); if (G.mode === 'creative' && n - lastSpace < 300) { G.fly = !G.fly; P.vy = 0; toast(G.fly ? 'Flying on' : 'Flying off'); } lastSpace = n; }
  if (e.code === 'KeyE') openPanel();
  if (e.code === 'KeyG' && G.mode === 'creative') { G.fly = !G.fly; }
  if (e.code.startsWith('Digit')) { const n = +e.code.slice(5); if (n >= 1 && n <= 9) { G.sel = n - 1; hudDirty = true; showHeld(); } }
});
window.addEventListener('keyup', e => keys.delete(e.code));
window.addEventListener('blur', () => { keys.clear(); mine.btn = false; });
canvas.addEventListener('wheel', e => { if (!G.playing) return; G.sel = (G.sel + (e.deltaY > 0 ? 1 : 8)) % 9; hudDirty = true; showHeld(); }, { passive: true });
canvas.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('mousemove', e => {
  if (!G.playing || TOUCH) return;
  if (document.pointerLockElement) look(e.movementX, e.movementY, 0.0024);
  else if (drag.id === 'mouse') dragMove(e.clientX, e.clientY);
});
canvas.addEventListener('mousedown', e => {
  if (!G.playing || TOUCH) return;
  if (!document.pointerLockElement && !G.lockFailed) { lockPointer(); return; }
  if (G.lockFailed && !document.pointerLockElement) { if (e.button === 0) dragStart('mouse', e.clientX, e.clientY); else if (e.button === 2) doPlace(); return; }
  if (e.button === 0) { mine.btn = true; hitMob(); } else if (e.button === 2) doPlace();
});
window.addEventListener('mouseup', e => { if (e.button === 0) { mine.btn = false; if (drag.id === 'mouse') dragEnd(); } });
function look(dx, dy, s) { P.yaw -= dx * s; P.pitch = Math.max(-1.55, Math.min(1.55, P.pitch - dy * s)); }

/* touch / drag gestures: drag looks, tap places or hits, hold still mines */
const drag = { id: null, sx: 0, sy: 0, lx: 0, ly: 0, t0: 0, moved: false };
function dragStart(id, x, y) { drag.id = id; drag.sx = drag.lx = x; drag.sy = drag.ly = y; drag.t0 = performance.now(); drag.moved = false; }
function dragMove(x, y) { if (Math.hypot(x - drag.sx, y - drag.sy) > 12) drag.moved = true; look(x - drag.lx, y - drag.ly, 0.005); drag.lx = x; drag.ly = y; }
function dragEnd() { if (drag.id !== null && !drag.moved && performance.now() - drag.t0 < 260) { if (mobTarget) hitMob(); else doPlace(); } drag.id = null; }
canvas.addEventListener('touchstart', e => { if (!G.playing) return; e.preventDefault(); if (drag.id === null) { const t = e.changedTouches[0]; dragStart(t.identifier, t.clientX, t.clientY); } }, { passive: false });
canvas.addEventListener('touchmove', e => { e.preventDefault(); for (const t of e.changedTouches) if (t.identifier === drag.id) dragMove(t.clientX, t.clientY); }, { passive: false });
const touchEnd = e => { for (const t of e.changedTouches) if (t.identifier === drag.id) dragEnd(); };
canvas.addEventListener('touchend', touchEnd); canvas.addEventListener('touchcancel', () => { drag.id = null; });

/* joystick + buttons */
(function () {
  const j = $('joy'), k = $('knob'), maxR = 48;
  const upd = (t) => { const r = j.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2; let dx = t.clientX - cx, dy = t.clientY - cy; const l = Math.hypot(dx, dy), m = l > maxR ? maxR / l : 1; dx *= m; dy *= m; k.style.transform = 'translate(' + dx + 'px,' + dy + 'px)'; joy.x = dx / maxR; joy.y = dy / maxR; joy.sprint = l > maxR * 1.05 || Math.hypot(joy.x, joy.y) > 0.98; };
  j.addEventListener('touchstart', e => { e.preventDefault(); e.stopPropagation(); joy.id = e.changedTouches[0].identifier; upd(e.changedTouches[0]); }, { passive: false });
  j.addEventListener('touchmove', e => { e.preventDefault(); for (const t of e.changedTouches) if (t.identifier === joy.id) upd(t); }, { passive: false });
  const end = e => { for (const t of e.changedTouches) if (t.identifier === joy.id) { joy.id = null; joy.x = joy.y = 0; joy.sprint = false; k.style.transform = ''; } };
  j.addEventListener('touchend', end); j.addEventListener('touchcancel', end);
  const hold = (id, on, off) => { const b = $(id); b.addEventListener('touchstart', e => { e.preventDefault(); e.stopPropagation(); b.classList.add('on'); on(); }, { passive: false }); const f = e => { e.preventDefault(); b.classList.remove('on'); off && off(); }; b.addEventListener('touchend', f); b.addEventListener('touchcancel', f); };
  hold('tJump', () => { tbtn.jump = true; }, () => { tbtn.jump = false; });
  hold('tDown', () => { tbtn.down = true; }, () => { tbtn.down = false; });
  hold('tBreak', () => { mine.btn = true; hitMob(); }, () => { mine.btn = false; });
  hold('tPlace', () => { if (!eatIfFood()) doPlace(); });
  hold('tFly', () => { if (G.mode === 'creative') { G.fly = !G.fly; P.vy = 0; toast(G.fly ? 'Flying on' : 'Flying off'); } else toast('Flying is for creative worlds'); });
  hold('tBag', () => openPanel());
  hold('tMenu', () => pauseGame());
})();

/* ---------- collision & physics ---------- */
function hits(x, y, z, hw, h) {
  const x0 = Math.floor(x - hw), x1 = Math.floor(x + hw), y0 = Math.floor(y), y1 = Math.floor(y + h - 0.001), z0 = Math.floor(z - hw), z1 = Math.floor(z + hw);
  for (let yy = y0; yy <= y1; yy++) for (let zz = z0; zz <= z1; zz++) for (let xx = x0; xx <= x1; xx++) if (SOLID[getBlock(xx, yy, zz)]) return true;
  return false;
}
function moveBody(o, dt, hw, h) {
  let blocked = false; o.ground = false;
  let nx = o.x + o.vx * dt; if (hits(nx, o.y, o.z, hw, h)) { o.vx = 0; blocked = true; } else o.x = nx;
  let nz = o.z + o.vz * dt; if (hits(o.x, o.y, nz, hw, h)) { o.vz = 0; blocked = true; } else o.z = nz;
  let ny = o.y + o.vy * dt; if (hits(o.x, ny, o.z, hw, h)) { if (o.vy < 0) o.ground = true; o.vy = 0; } else o.y = ny;
  return blocked;
}
function isWaterAt(x, y, z) { return getBlock(Math.floor(x), Math.floor(y), Math.floor(z)) === B.WATER; }
function hurt(n, from) {
  if (G.mode === 'creative' || n <= 0) return;
  G.hp -= n; P.hurtT = 0.4; hudDirty = true; sfx.hurt();
  if (from) { const dx = P.x - from.x, dz = P.z - from.z, l = Math.hypot(dx, dz) || 1; P.vx += dx / l * 5; P.vz += dz / l * 5; P.vy = 4; }
  if (G.hp <= 0) { G.hp = 20; P.x = spawn.x; P.y = spawn.y; P.z = spawn.z; P.vx = P.vy = P.vz = 0; P.fall = 0; toast('You died. Back at spawn.'); }
}
function updatePlayer(dt) {
  const hw = 0.3, h = 1.8;
  let f = 0, s = 0, sprint = false;
  if (keys.has('KeyW') || keys.has('ArrowUp')) f += 1; if (keys.has('KeyS') || keys.has('ArrowDown')) f -= 1;
  if (keys.has('KeyD')) s += 1; if (keys.has('KeyA')) s -= 1;
  if (keys.has('ShiftLeft') || keys.has('ShiftRight') || keys.has('ControlLeft')) sprint = true;
  if (keys.has('ArrowLeft')) P.yaw += 2 * dt; if (keys.has('ArrowRight')) P.yaw -= 2 * dt;
  if (joy.id !== null) { f -= joy.y; s += joy.x; if (joy.sprint) sprint = true; }
  const l = Math.hypot(f, s); if (l > 1) { f /= l; s /= l; }
  const jump = keys.has('Space') || tbtn.jump, down = keys.has('ShiftLeft') || tbtn.down;
  P.inWater = isWaterAt(P.x, P.y + 0.4, P.z); P.headWater = isWaterAt(P.x, P.y + 1.62, P.z);
  let sp = G.fly ? 10 : sprint && f > 0.3 ? 5.8 : 4.3; if (P.inWater && !G.fly) sp = 2.6;
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  const tx = (-sy * f + cy * s) * sp, tz = (-cy * f - sy * s) * sp, k = Math.min(1, (P.ground || G.fly ? 14 : 4) * dt);
  P.vx += (tx - P.vx) * k; P.vz += (tz - P.vz) * k;
  if (G.fly) { P.vy += ((jump ? 8 : down ? -8 : 0) - P.vy) * Math.min(1, 10 * dt); }
  else if (P.inWater) { P.vy -= 9 * dt; if (jump) P.vy += 22 * dt; P.vy = Math.max(-3, Math.min(P.vy, 3.4)); P.fall = 0; }
  else { P.vy -= 28 * dt; if (P.vy < -50) P.vy = -50; if (jump && P.ground) { P.vy = 8.6; P.ground = false; } }
  const wasG = P.ground, vyBefore = P.vy;
  const blocked = moveBody(P, dt, hw, h);
  if (TOUCH && blocked && wasG && l > 0.2 && !G.fly) { if (!hits(P.x + tx * 0.08, P.y + 1.05, P.z + tz * 0.08, hw, h)) P.vy = 8.6; }
  if (G.fly && P.ground) { }
  if (!G.fly && !P.inWater) {
    if (vyBefore < 0) P.fall += -vyBefore * dt; if (P.vy > 0) P.fall = 0;
    if (P.ground) { if (P.fall > 3.6) hurt(Math.floor(P.fall - 3), null); P.fall = 0; }
  } else P.fall = 0;
  if (P.y < -20) { P.x = spawn.x; P.y = spawn.y; P.z = spawn.z; P.vy = 0; }
  if (P.hurtT > 0) P.hurtT -= dt;
  if (G.mode === 'survival' && G.hp < 20) { regenT += dt; if (regenT > 5) { regenT = 0; G.hp++; hudDirty = true; } }
}
let regenT = 0;

/* ---------- interaction ---------- */
const eye = () => [P.x, P.y + 1.62, P.z];
const fwd = () => [-Math.sin(P.yaw) * Math.cos(P.pitch), Math.sin(P.pitch), -Math.cos(P.yaw) * Math.cos(P.pitch)];
function rayBox(o, d, mn, mx) {
  let t0 = 0, t1 = 1e9;
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) { if (o[i] < mn[i] || o[i] > mx[i]) return null; }
    else { let a = (mn[i] - o[i]) / d[i], b = (mx[i] - o[i]) / d[i]; if (a > b) { const t = a; a = b; b = t; } t0 = Math.max(t0, a); t1 = Math.min(t1, b); if (t0 > t1) return null; }
  }
  return t0;
}
function updateTarget() {
  const e = eye(), d = fwd(), reach = G.mode === 'creative' ? 6 : 4.6;
  target = raycast(e[0], e[1], e[2], d[0], d[1], d[2], reach); mobTarget = null;
  let best = target ? target.t : reach + 1;
  for (const m of mobs) {
    const hw = m.def.w, t = rayBox(e, d, [m.x - hw, m.y, m.z - hw], [m.x + hw, m.y + m.def.h, m.z + hw]);
    if (t !== null && t < Math.min(best, 3.6)) { best = t; mobTarget = m; }
  }
  if (mobTarget) target = null;
}
function hitMob() {
  if (!G.playing) return; updateTarget(); const m = mobTarget; if (!m || m.hitCd > 0) return;
  m.hitCd = 0.45; const tw = heldTool(); m.hp -= G.mode === 'creative' ? 8 : tw ? DMG[tw.type][tw.tier] : 1.5; if (tw) useTool(); m.hurt = 0.3; sfx.hit();
  const dx = m.x - P.x, dz = m.z - P.z, l = Math.hypot(dx, dz) || 1; m.vx = dx / l * 6; m.vz = dz / l * 6; m.vy = 4;
  if (m.type !== 'zombie') { m.flee = 4; m.dir = Math.atan2(dx, dz); }
  if (m.hp <= 0) killMob(m);
}
function killMob(m) { m.dead = true; for (let i = 0; i < 10; i++) spark(m.x, m.y + 0.6, m.z, m.def.col); if (m.def.drop) { addItem(20, 1 + (Math.random() < 0.4 ? 1 : 0)); toast('+ Raw Meat'); } sfx.pop(); }
function eatIfFood() { if (hot[G.sel] === 20 && G.mode === 'survival') { if (G.hp < 20 && takeItem(20)) { G.hp = Math.min(20, G.hp + 6); hudDirty = true; sfx.pop(); } else if (G.hp >= 20) toast('You are not hurt'); return true; } return false; }
function doPlace() {
  if (!G.playing) return; if (eatIfFood()) return; updateTarget(); const t = target; if (!t) return;
  if (t.id === B.TABLE || t.id === B.FURNACE) { openPanel(); return; }
  if (t.id === B.ANVIL) { const tid = hot[G.sel]; if (TOOL(tid) && G.mode === 'survival') { if (dura.has(tid) && takeItem(23)) { dura.delete(tid); hudDirty = true; sfx.pop(); toast('Repaired ' + ITEMNAME(tid)); } else toast(dura.has(tid) ? 'Repairs cost 1 Iron Ingot' : 'Nothing to repair'); } else toast('Hold a damaged tool and use the anvil'); return; }
  const id = hot[G.sel]; if (!id || id >= 20) return;
  const x = t.x + t.nx, y = t.y + t.ny, z = t.z + t.nz; if (y < 0 || y >= H) return;
  const cur = getBlock(x, y, z); if (cur && cur !== B.WATER) return;
  if (SOLID[id] && P.x - 0.3 < x + 1 && P.x + 0.3 > x && P.y < y + 1 && P.y + 1.8 > y && P.z - 0.3 < z + 1 && P.z + 0.3 > z) return;
  if (!takeItem(id)) return;
  setBlock(x, y, z, id); sfx.put();
}
const BCOL = { 1: [0.35, 0.6, 0.2], 2: [0.48, 0.34, 0.23], 3: [0.54, 0.54, 0.55], 4: [0.87, 0.82, 0.6], 5: [0.4, 0.31, 0.19], 6: [0.18, 0.46, 0.15], 7: [0.7, 0.55, 0.33], 8: [0.5, 0.5, 0.52], 10: [0.2, 0.2, 0.22], 11: [0.27, 0.27, 0.3], 12: [0.78, 0.9, 0.95] };
function spark(x, y, z, col) { if (parts.length > 160) parts.shift(); parts.push({ x, y, z, vx: (Math.random() - 0.5) * 4, vy: 1 + Math.random() * 3.5, vz: (Math.random() - 0.5) * 4, life: 0.6 + Math.random() * 0.4, col }); }
function toolFor(id) { const t = heldTool(); return t && MATCH[t.type] && MATCH[t.type].includes(id) ? t : null; }
function breakBlock(t) {
  const id = t.id; if (id === B.BEDROCK && G.mode !== 'creative') return;
  setBlock(t.x, t.y, t.z, 0);
  for (let i = 0; i < 9; i++) spark(t.x + Math.random(), t.y + Math.random(), t.z + Math.random(), BCOL[id] || [0.5, 0.5, 0.5]);
  const tl = toolFor(id), pk = heldTool(); let ok = true;
  if (G.mode === 'survival') { const needP = MATCH[0].includes(id), minT = id === B.IRON ? 1 : 0; if (needP) ok = !!pk && pk.type === 0 && pk.tier >= minT; }
  const d = DROP(id); if (d && ok) addItem(d, 1); else if (d && !ok) toast('Wrong tool, nothing dropped');
  if (tl) useTool(); sfx.brk();
}
function updateMining(dt) {
  const holding = mine.btn || (drag.id !== null && !drag.moved && performance.now() - drag.t0 > 260);
  extra.hl = target ? { x: target.x, y: target.y, z: target.z } : null;
  if (holding && mobTarget) { const m = mobTarget; if (m.hitCd <= 0) hitMob(); brkProg = 0; extra.brk = 0; return; }
  if (holding && target) {
    const key = target.x + ',' + target.y + ',' + target.z;
    if (key !== brkKey) { brkKey = key; brkProg = 0; }
    const tl = toolFor(target.id), need = G.mode === 'creative' ? 0.12 : (target.id === B.BEDROCK ? 1e9 : (HARD[target.id] || 1) / (tl ? TMULT[tl.tier] : 1));
    brkProg += dt; extra.brk = brkProg / need;
    $('bar').style.display = 'block'; $('bar').firstElementChild.style.width = Math.min(100, extra.brk * 100) + '%';
    if (brkProg >= need) { breakBlock(target); brkProg = 0; brkKey = ''; if (G.mode === 'creative') mine.btn = mine.btn; }
  } else { brkProg = 0; brkKey = ''; extra.brk = 0; $('bar').style.display = 'none'; }
}

/* ---------- mobs ---------- */
const MOBDEF = {
  zombie: { w: 0.3, h: 1.8, hp: 8, spd: 2.5, col: [0.35, 0.58, 0.32], parts: [
    { c: [0, 1.65, 0], h: [.25, .25, .25], col: [0.4, 0.64, 0.36] }, { c: [0, 1.125, 0], h: [.25, .375, .125], col: [0.2, 0.46, 0.62] },
    { c: [-.375, 1.4, .3], h: [.125, .125, .375], col: [0.4, 0.64, 0.36] }, { c: [.375, 1.4, .3], h: [.125, .125, .375], col: [0.4, 0.64, 0.36] },
    { c: [-.125, .375, 0], h: [.125, .375, .125], col: [0.25, 0.23, 0.52], leg: 1 }, { c: [.125, .375, 0], h: [.125, .375, .125], col: [0.25, 0.23, 0.52], leg: -1 }] },
  pig: { w: 0.4, h: 0.9, hp: 6, spd: 1.4, drop: 1, col: [0.95, 0.62, 0.62], parts: [
    { c: [0, .6, 0], h: [.3, .25, .45], col: [0.95, 0.62, 0.62] }, { c: [0, .66, .55], h: [.22, .22, .2], col: [0.96, 0.66, 0.66] }, { c: [0, .58, .78], h: [.12, .09, .05], col: [0.86, 0.5, 0.52] },
    { c: [-.2, .2, .3], h: [.1, .2, .1], col: [0.88, 0.55, 0.56], leg: 1 }, { c: [.2, .2, .3], h: [.1, .2, .1], col: [0.88, 0.55, 0.56], leg: -1 },
    { c: [-.2, .2, -.3], h: [.1, .2, .1], col: [0.88, 0.55, 0.56], leg: -1 }, { c: [.2, .2, -.3], h: [.1, .2, .1], col: [0.88, 0.55, 0.56], leg: 1 }] },
  sheep: { w: 0.4, h: 1.3, hp: 6, spd: 1.3, drop: 1, col: [0.92, 0.92, 0.88], parts: [
    { c: [0, .85, 0], h: [.32, .3, .5], col: [0.92, 0.92, 0.88] }, { c: [0, .95, .62], h: [.16, .18, .17], col: [0.4, 0.34, 0.3] },
    { c: [-.2, .3, .3], h: [.08, .3, .08], col: [0.4, 0.34, 0.3], leg: 1 }, { c: [.2, .3, .3], h: [.08, .3, .08], col: [0.4, 0.34, 0.3], leg: -1 },
    { c: [-.2, .3, -.3], h: [.08, .3, .08], col: [0.4, 0.34, 0.3], leg: -1 }, { c: [.2, .3, -.3], h: [.08, .3, .08], col: [0.4, 0.34, 0.3], leg: 1 }] },
};
const SKIN = { zombie: SKINS.zombie.parts, pig: SKINS.pig.parts, sheep: SKINS.sheep.parts };
let userSkins = {};
let spawnT = 0;
function trySpawn(dt, env) {
  spawnT += dt; if (spawnT < 1.5) return; spawnT = 0;
  const night = env.day < 0.3, hostile = mobs.filter(m => m.type === 'zombie').length, passive = mobs.length - hostile;
  const a = Math.random() * 6.283, r = 20 + Math.random() * 22, x = Math.floor(P.x + Math.cos(a) * r), z = Math.floor(P.z + Math.sin(a) * r);
  const c = chunks.get(ck(x >> 4, z >> 4)); if (!c) return;
  const y = getTop(x, z) + 1, under = getBlock(x, y - 1, z); if (y < 2 || y >= H - 3) return;
  if (getBlock(x, y, z) || getBlock(x, y + 1, z)) return;
  if (night && G.mode === 'survival' && hostile < 8 && under !== B.WATER && under !== B.LEAVES) addMob('zombie', x + 0.5, y, z + 0.5);
  else if (!night && passive < 9 && under === B.GRASS && Math.random() < 0.6) addMob(Math.random() < 0.5 ? 'pig' : 'sheep', x + 0.5, y, z + 0.5);
}
function addMob(type, x, y, z) { mobs.push({ type, def: MOBDEF[type], x, y, z, vx: 0, vy: 0, vz: 0, hp: MOBDEF[type].hp, dir: Math.random() * 6.28, wt: 0, walk: 0, hitCd: 0, hurt: 0, atk: 0, flee: 0, ground: false }); }
function updateMobs(dt, env) {
  for (const m of mobs) {
    const d = m.def; if (m.hitCd > 0) m.hitCd -= dt; if (m.hurt > 0) m.hurt -= dt; if (m.flee > 0) m.flee -= dt;
    const dx = P.x - m.x, dz = P.z - m.z, dist = Math.hypot(dx, dz);
    let want = 0;
    if (m.type === 'zombie') {
      if (env.day > 0.7 && getTop(Math.floor(m.x), Math.floor(m.z)) < m.y + 1) { m.burn = (m.burn || 0) + dt; if (m.burn > 1) { m.burn = 0; m.hp -= 2; m.hurt = 0.3; if (m.hp <= 0) m.dead = true; } }
      if (dist < 26 && G.mode === 'survival') { m.dir = Math.atan2(dx, dz); want = d.spd; }
      else { m.wt -= dt; if (m.wt < 0) { m.wt = 2 + Math.random() * 3; m.dir = Math.random() * 6.28; m.still = Math.random() < 0.4; } want = m.still ? 0 : d.spd * 0.4; }
      m.atk -= dt; if (dist < 1.1 && Math.abs(P.y - m.y) < 1.6 && m.atk <= 0 && G.mode === 'survival') { m.atk = 1.1; hurt(3, m); }
    } else {
      m.wt -= dt; if (m.wt < 0) { m.wt = 1.5 + Math.random() * 4; m.dir = Math.random() * 6.28; m.still = Math.random() < 0.5; }
      want = m.flee > 0 ? d.spd * 2.2 : m.still ? 0 : d.spd;
    }
    const tx = Math.sin(m.dir) * want, tz = Math.cos(m.dir) * want, k = Math.min(1, 8 * dt);
    m.vx += (tx - m.vx) * k; m.vz += (tz - m.vz) * k;
    const inW = isWaterAt(m.x, m.y + 0.3, m.z);
    m.vy -= (inW ? 6 : 28) * dt; if (inW) { m.vy = Math.max(m.vy, -2); if (want > 0) m.vy = 2.2; } if (m.vy < -40) m.vy = -40;
    const blocked = moveBody(m, dt, d.w, d.h);
    if (blocked && m.ground && want > 0 && !hits(m.x + Math.sin(m.dir) * 0.6, m.y + 1, m.z + Math.cos(m.dir) * 0.6, d.w, d.h)) m.vy = 8.2;
    else if (blocked && want > 0 && m.type !== 'zombie') m.dir += 1.7;
    m.walk += Math.hypot(m.vx, m.vz) * dt * 3.2;
    if (m.y < -10) m.dead = true;
    if (dist > 80) m.dead = true;
  }
  mobs = mobs.filter(m => !m.dead);
  for (const p of parts) { p.vy -= 20 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.life -= dt; }
  parts = parts.filter(p => p.life > 0);
}
function buildDyn() {
  const o = [], tb = {}; extra.tb = tb;
  for (const m of mobs) {
    const sw = Math.sin(m.walk) * 0.7 * Math.min(1, Math.hypot(m.vx, m.vz) * 0.9), yaw = m.type === 'zombie' && Math.hypot(m.vx, m.vz) < 0.05 ? m.dir : Math.atan2(m.vx, m.vz) || m.dir;
    m.yaw = m.yaw === undefined ? yaw : m.yaw + Math.atan2(Math.sin(yaw - m.yaw), Math.cos(yaw - m.yaw)) * 0.2;
    const sk = userSkins[m.type];
    if (sk) {
      for (const p of SKIN[m.type]) {
        const tx = p.fur ? userSkins.sheep_fur : sk, ang = (p.a0 || 0) + (p.leg ? sw * p.leg : 0);
        if (tx) { const q = tb[tx.key] || (tb[tx.key] = { sk: tx, arr: [] }); pushTexBox(q.arr, { c: p.c, s: p.s, uvs: p.uvs || p.s, uv: p.uv, pv: p.pv, tw: tx.w, th: tx.h, yaw: m.yaw, ang, ox: m.x, oy: m.y, oz: m.z }); }
        else pushBox(o, { cx: p.c[0] / 16, cy: p.c[1] / 16, cz: p.c[2] / 16, hx: p.s[0] / 32, hy: p.s[1] / 32, hz: p.s[2] / 32, yaw: m.yaw, ang, py: p.pv / 16, pz: p.c[2] / 16, ox: m.x, oy: m.y, oz: m.z, col: p.col || [0.6, 0.6, 0.6] });
      }
      continue;
    }
    for (const p of m.def.parts) {
      const col = m.hurt > 0 ? [Math.min(1, p.col[0] + 0.5), p.col[1] * 0.5, p.col[2] * 0.5] : p.col;
      pushBox(o, { cx: p.c[0], cy: p.c[1], cz: p.c[2], hx: p.h[0], hy: p.h[1], hz: p.h[2], yaw: m.yaw, ang: p.leg ? sw * p.leg : 0, py: p.c[1] + p.h[1], pz: p.c[2], ox: m.x, oy: m.y, oz: m.z, col });
    }
  }
  for (const p of parts) pushCube(o, p.x - 0.05, p.y - 0.05, p.z - 0.05, p.x + 0.05, p.y + 0.05, p.z + 0.05, p.col[0], p.col[1], p.col[2], 1);
  return o;
}

/* ---------- environment ---------- */
const mix3 = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
const sstep = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
function envFor(t, under) {
  const ang = t * 6.28318, sy = Math.sin(ang), sd = [Math.cos(ang) * 0.9, sy, 0.3], l = Math.hypot(sd[0], sd[1], sd[2]); sd[0] /= l; sd[1] /= l; sd[2] /= l;
  const day = sstep(-0.12, 0.3, sy), night = 1 - sstep(-0.3, 0.05, sy);
  let sky = mix3([0.015, 0.025, 0.07], [0.48, 0.66, 1.0], day);
  const tw = Math.max(0, 1 - Math.abs(sy) / 0.22); sky = mix3(sky, [0.95, 0.52, 0.32], tw * 0.5);
  let fogEnd = Math.max(60, G.rd * 16 * 0.97);
  if (under) { sky = mix3([0.04, 0.09, 0.22], [0.12, 0.3, 0.62], day); fogEnd = 18; }
  return { day, night, sky, sunDir: sd, fogEnd, time: performance.now() / 1000 };
}

/* ---------- streaming ---------- */
function streamChunks(fx, fz, budgetMs) {
  const pcx = Math.floor(fx / 16), pcz = Math.floor(fz / 16), key = pcx + ',' + pcz + ',' + G.rd;
  if (key !== lastPC) {
    lastPC = key; needed = []; const r = G.rd + 1;
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) { const d2 = dx * dx + dz * dz; if (d2 <= r * r + 1) needed.push([pcx + dx, pcz + dz, d2]); }
    needed.sort((a, b) => a[2] - b[2]);
    for (const [k, c] of chunks) { const dx = c.cx - pcx, dz = c.cz - pcz; if (dx * dx + dz * dz > (G.rd + 3) * (G.rd + 3)) { freeMesh(c); chunks.delete(k); } }
  }
  const t0 = performance.now();
  for (const c of chunks.values()) if (c.now && c.dirty && c.mesh) meshChunk(c);
  for (const n of needed) {
    if (performance.now() - t0 > budgetMs) return;
    const k = ck(n[0], n[1]); if (!chunks.has(k)) chunks.set(k, genChunk(n[0], n[1]));
  }
  for (const n of needed) {
    if (n[2] > G.rd * G.rd + 1) continue; if (performance.now() - t0 > budgetMs * 1.8) return;
    const c = chunks.get(ck(n[0], n[1])); if (!c || (!c.dirty && c.mesh)) continue;
    if (chunks.has(ck(n[0] + 1, n[1])) && chunks.has(ck(n[0] - 1, n[1])) && chunks.has(ck(n[0], n[1] + 1)) && chunks.has(ck(n[0], n[1] - 1))) meshChunk(c);
  }
}

/* ---------- main loop ---------- */
function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, TOUCH ? 1.25 : 1.5), w = Math.max(1, Math.floor(window.innerWidth * dpr)), h = Math.max(1, Math.floor(window.innerHeight * dpr));
  if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
}
window.addEventListener('resize', resize); resize();
let last = performance.now(), attract = { yaw: 0 };
function frame(now) {
  requestAnimationFrame(frame); if (!glOK) return;
  let dt = Math.min(0.05, (now - last) / 1000); last = now; resize();
  fpsAcc += dt; fpsN++; if (fpsAcc > 0.5) { fps = Math.round(fpsN / fpsAcc); fpsAcc = 0; fpsN = 0; }
  let cam, env;
  if (G.started) {
    if (G.playing) {
      G.time = (G.time + dt / 480) % 1;
      updatePlayer(dt); updateTarget(); updateMining(dt); env = envFor(G.time, P.headWater);
      trySpawn(dt, env); updateMobs(dt, env);
      saveT += dt; if (saveT > 20) { saveT = 0; saveGame(); }
    } else env = envFor(G.time, P.headWater);
    cam = { x: P.x, y: P.y + 1.62, z: P.z, yaw: P.yaw, pitch: P.pitch, fov: (G.fly ? 1.2 : 1.12) };
    streamChunks(P.x, P.z, TOUCH ? 4 : 6);
  } else {
    attract.yaw += dt * 0.05; G.time = 0.15 + (now / 1000) * 0.0004;
    cam = { x: spawn.x, y: spawn.y + 14, z: spawn.z, yaw: attract.yaw, pitch: -0.28, fov: 1.1 }; env = envFor(G.time, false);
    streamChunks(spawn.x, spawn.z, 6);
  }
  extra.renderDist = G.rd; extra.mobs = G.started ? buildDyn() : [];
  if (!G.started || !G.playing) { extra.hl = null; extra.brk = 0; }
  renderFrame(cam, env, extra);
  if (G.started) {
    if (hudDirty) buildHotbar();
    $('hurt').style.opacity = P.hurtT > 0 ? Math.min(1, P.hurtT * 2.5) : 0;
    $('under').style.opacity = P.headWater ? 1 : 0;
    const hr = ((G.time * 24 + 6) % 24); $('clock').textContent = String(Math.floor(hr)).padStart(2, '0') + ':' + String(Math.floor((hr % 1) * 60)).padStart(2, '0') + (env.day < 0.3 ? '  night' : '');
    if (showDbg) $('debug').textContent = 'FPS ' + fps + '\nXYZ ' + P.x.toFixed(1) + ' ' + P.y.toFixed(1) + ' ' + P.z.toFixed(1) + '\nChunks ' + chunks.size + '  drawn ' + extra.drawn + '\nMobs ' + mobs.length + '  seed ' + SEED;
  }
}


/* ---------- optional texture packs, loaded from the player's own files and kept on their device ---------- */
const BLOCKMAP = {}; for (const t of TILES) { BLOCKMAP[t.name] = t.t; (t.alias || []).forEach(n => BLOCKMAP[n] = t.t); }
const userTiles = new Map();
function rebuildAtlas() {
  const cv = document.createElement('canvas'); cv.width = cv.height = 256; const g = cv.getContext('2d'); g.imageSmoothingEnabled = false;
  g.drawImage(atlasCv, 0, 0);
  userTiles.forEach((s, t) => { const dx = (t % 16) * 16, dy = Math.floor(t / 16) * 16; g.clearRect(dx, dy, 16, 16); g.drawImage(s.img, s.sx, s.sy, s.sw, s.sh, dx, dy, 16, 16); });
  const gl = R.gl; gl.bindTexture(gl.TEXTURE_2D, R.tex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cv);
  curAtlas = cv; applyTints();
}
$('blockIn').onchange = async e => {
  const files = await expandFiles([...e.target.files]); let n = 0, atlas = false;
  for (const f of files) {
    if (/pack\.json$/i.test(f.name)) { try { const j = JSON.parse(await f.text()); if (j.tint) { tintCfg.grass = j.tint.grass || tintCfg.grass; tintCfg.foliage = j.tint.foliage || tintCfg.foliage; $('grassCol').value = tintCfg.grass; $('leafCol').value = tintCfg.foliage; applyTints(); saveTint(); } } catch (er) { } continue; }
    let img; try { img = await createImageBitmap(f); } catch (er) { continue; }
    const key = baseName(f), t = BLOCKMAP[key];
    if (t !== undefined) { userTiles.set(t, { img, sx: 0, sy: 0, sw: img.width, sh: key === 'water_still' ? img.width : img.height }); n++; }
    else if (img.width === img.height && img.width >= 256 && img.width % 16 === 0) { const ts = img.width / 16; for (const ti in CLASSIC) { const src = CLASSIC[ti]; userTiles.set(+ti, { img, sx: (src % 16) * ts, sy: Math.floor(src / 16) * ts, sw: ts, sh: ts }); } atlas = true; n++; }
  }
  if (n) rebuildAtlas();
  $('blockStat').textContent = n ? (atlas ? 'Atlas loaded.' : n + ' block and item textures loaded.') : 'No matching files. Use names like grass_top.png, dirt.png, iron_ore.png.';
};
$('blockReset').onclick = () => { userTiles.clear(); rebuildAtlas(); $('blockStat').textContent = 'Using the built-in textures.'; $('blockIn').value = ''; };
$('mobIn').onchange = async e => {
  const got = [];
  for (const f of await expandFiles([...e.target.files])) {
    const key = baseName(f).replace(/^(entity\/)?/, '').replace('sheep_fur', 'sheep_fur'); if (!['zombie', 'pig', 'sheep', 'sheep_fur'].includes(key)) continue;
    let bmp; try { bmp = await createImageBitmap(f); } catch (er) { continue; }
    const sk = makeSkinTex(bmp); sk.key = key; userSkins[key] = sk; got.push(key);
  }
  $('mobStat').textContent = got.length ? 'Loaded: ' + got.join(', ') : 'No matching files. Use zombie.png, pig.png, sheep.png, sheep_fur.png.';
};
$('mobReset').onclick = () => { userSkins = {}; $('mobStat').textContent = 'Using the built-in mobs.'; $('mobIn').value = ''; };

/* ---------- colours ---------- */
$('grassCol').value = tintCfg.grass; $('leafCol').value = tintCfg.foliage;
const saveTint = () => { try { localStorage.setItem('blockland-tint', JSON.stringify(tintCfg)); } catch (e) { } };
$('grassCol').oninput = e => { tintCfg.grass = e.target.value; applyTints(); saveTint(); };
$('leafCol').oninput = e => { tintCfg.foliage = e.target.value; applyTints(); saveTint(); };
$('colReset').onclick = () => { tintCfg.grass = TINT_DEFAULT.grass[0]; tintCfg.foliage = TINT_DEFAULT.foliage[0]; $('grassCol').value = tintCfg.grass; $('leafCol').value = tintCfg.foliage; applyTints(); saveTint(); };
applyTints();

/* ---------- menu wiring ---------- */
const sv = readSave();
if (sv) { $('btnPlay').textContent = 'Continue'; $('saveNote').textContent = 'A saved world was found in this browser.'; }
$('btnPlay').onclick = () => { if (G.started) resumeGame(); else if (sv) startGame(sv); else startGame(null, '', 'survival'); };
$('btnNew').onclick = () => { const b = $('newBox'); b.style.display = b.style.display === 'flex' ? 'none' : 'flex'; };
$('btnStart').onclick = () => { startGame(null, $('seedIn').value.trim(), $('modeCre').checked ? 'creative' : 'survival'); };
$('rdIn').oninput = e => { G.rd = +e.target.value; $('rdVal').textContent = G.rd + ' chunks'; };
if (TOUCH) { G.rd = 4; $('rdIn').value = 4; $('rdVal').textContent = '4 chunks'; }
document.querySelectorAll('#timeRow button').forEach(b => b.onclick = () => { G.time = +b.dataset.t; });
window.addEventListener('pagehide', saveGame);
document.addEventListener('visibilitychange', () => { if (document.hidden) { if (G.playing) pauseGame(); else saveGame(); } });
if (glOK) { resetWorld(Math.floor(Math.random() * 1e9)); spawn = findSpawn(); preload(Math.floor(spawn.x / 16), Math.floor(spawn.z / 16), 3); }
requestAnimationFrame(frame);
