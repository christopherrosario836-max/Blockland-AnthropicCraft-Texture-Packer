/* ---------- matrices ---------- */
const mat = {
  mul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; },
  persp(fov, asp, n, f) { const t = 1 / Math.tan(fov / 2), o = new Float32Array(16); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = 2 * f * n / (n - f); return o; },
  rx(a) { const o = new Float32Array(16), c = Math.cos(a), s = Math.sin(a); o[0] = 1; o[5] = c; o[6] = s; o[9] = -s; o[10] = c; o[15] = 1; return o; },
  ry(a) { const o = new Float32Array(16), c = Math.cos(a), s = Math.sin(a); o[0] = c; o[2] = -s; o[5] = 1; o[8] = s; o[10] = c; o[15] = 1; return o; },
  tr(x, y, z) { const o = new Float32Array(16); o[0] = o[5] = o[10] = o[15] = 1; o[12] = x; o[13] = y; o[14] = z; return o; },
};
function frustumPlanes(m) {
  const p = [], row = i => [m[i], m[4 + i], m[8 + i], m[12 + i]];
  const r0 = row(0), r1 = row(1), r2 = row(2), r3 = row(3);
  const add = (a, b, s) => p.push([a[0] + s * b[0], a[1] + s * b[1], a[2] + s * b[2], a[3] + s * b[3]]);
  add(r3, r0, 1); add(r3, r0, -1); add(r3, r1, 1); add(r3, r1, -1); add(r3, r2, 1); add(r3, r2, -1);
  return p;
}
function boxInFrustum(pl, x0, y0, z0, x1, y1, z1) {
  for (const q of pl) {
    const px = q[0] > 0 ? x1 : x0, py = q[1] > 0 ? y1 : y0, pz = q[2] > 0 ? z1 : z0;
    if (q[0] * px + q[1] * py + q[2] * pz + q[3] < 0) return false;
  }
  return true;
}

/* ---------- WebGL ---------- */
const R = { gl: null, cloudKey: '', cloudN: 0 };
const VS_B = `#version 300 es
in vec3 aPos; in vec2 aUV; in float aShade; in float aTint;
uniform mat4 uVP; uniform vec3 uOff;
out vec2 vUV; out float vShade; out float vSky; out float vW; out float vTint;
void main(){ vec4 p=uVP*vec4(aPos+uOff,1.0); gl_Position=p; vUV=aUV; vTint=aTint; float s=step(2.0,aShade); vSky=s; vShade=aShade-2.0*s; vW=p.w; }`;
const FS_B = `#version 300 es
precision mediump float;
in vec2 vUV; in float vShade; in float vSky; in float vW; in float vTint;
uniform sampler2D uTex; uniform float uDay; uniform vec3 uFog; uniform vec2 uFogRange; uniform float uWater; uniform vec3 uTint[4];
out vec4 o;
void main(){ vec4 t=texture(uTex,vUV); if(uWater<0.5 && t.a<0.5) discard;
  vec3 tc=vec3(1.0); if(vTint>0.5){ if(vTint<2.5) tc=mix(uTint[0],uTint[1],vTint-1.0); else tc=mix(uTint[2],uTint[3],vTint-3.0); }
  float dl=mix(0.16,1.0,uDay); float l=mix(0.30,dl,vSky)*vShade; vec3 c=t.rgb*tc*l;
  float f=clamp((vW-uFogRange.x)/(uFogRange.y-uFogRange.x),0.0,1.0); c=mix(c,uFog,f);
  o=vec4(c, uWater>0.5 ? t.a*0.78 : 1.0); }`;
const VS_C = `#version 300 es
in vec3 aPos; in vec4 aCol;
uniform mat4 uVP; uniform float uPt;
out vec4 vC; out float vE; out float vW;
void main(){ vec4 p=uVP*vec4(aPos,1.0); gl_Position=p; gl_PointSize=uPt; vC=vec4(aCol.rgb,abs(aCol.a)); vE=aCol.a<0.0?1.0:0.0; vW=p.w; }`;
const FS_C = `#version 300 es
precision mediump float;
in vec4 vC; in float vE; in float vW;
uniform float uTint; uniform float uAlpha; uniform vec3 uFog; uniform vec2 uFogRange;
out vec4 o;
void main(){ vec3 c=vC.rgb*mix(uTint,1.0,vE); float f=clamp((vW-uFogRange.x)/(uFogRange.y-uFogRange.x),0.0,1.0); c=mix(c,uFog,f); o=vec4(c,vC.a*uAlpha); }`;

function mkProg(gl, vs, fs, names) {
  const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; };
  const p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  p.u = {}; for (const n of names) p.u[n] = gl.getUniformLocation(p, n);
  return p;
}
function initGL(canvas, atlasCanvas) {
  const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, powerPreference: 'high-performance' });
  if (!gl) return false;
  R.gl = gl; R.canvas = canvas;
  R.pB = mkProg(gl, VS_B, FS_B, ['uVP', 'uOff', 'uTex', 'uDay', 'uFog', 'uFogRange', 'uWater', 'uTint']);
  R.pC = mkProg(gl, VS_C, FS_C, ['uVP', 'uPt', 'uTint', 'uAlpha', 'uFog', 'uFogRange']);
  R.tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, R.tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, atlasCanvas);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  R.dyn = gl.createBuffer(); R.cloudBuf = gl.createBuffer(); R.starBuf = gl.createBuffer();
  const st = [], rr = mulberry32(4242);
  for (let i = 0; i < 380; i++) { const a = rr() * 6.2832, y = rr() * 2 - 0.15, r = Math.sqrt(Math.max(0, 1 - y * y)); st.push(Math.cos(a) * r * 300, y * 300, Math.sin(a) * r * 300, 1, 1, 1, -1); }
  R.nStars = st.length / 7; gl.bindBuffer(gl.ARRAY_BUFFER, R.starBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(st), gl.STATIC_DRAW);
  gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
  gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  return true;
}
function uploadMesh(c, data) {
  const gl = R.gl; freeMesh(c);
  const m = { n: data.o.length / 7, nw: data.w.length / 7, vb: null, vw: null };
  if (m.n) { m.vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, m.vb); gl.bufferData(gl.ARRAY_BUFFER, data.o, gl.STATIC_DRAW); }
  if (m.nw) { m.vw = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, m.vw); gl.bufferData(gl.ARRAY_BUFFER, data.w, gl.STATIC_DRAW); }
  c.mesh = m;
}
function freeMesh(c) { if (c.mesh) { if (c.mesh.vb) R.gl.deleteBuffer(c.mesh.vb); if (c.mesh.vw) R.gl.deleteBuffer(c.mesh.vw); c.mesh = null; } }

function bindColor(buf) {
  R.gl.disableVertexAttribArray(2); R.gl.disableVertexAttribArray(3);
  const gl = R.gl, p = R.pC, a = gl.getAttribLocation(p, 'aPos'), b = gl.getAttribLocation(p, 'aCol');
  gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 28, 0);
  gl.enableVertexAttribArray(b); gl.vertexAttribPointer(b, 4, gl.FLOAT, false, 28, 12);
}
function drawDyn(arr, mode) {
  const gl = R.gl; if (!arr.length) return;
  gl.bindBuffer(gl.ARRAY_BUFFER, R.dyn); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(arr), gl.STREAM_DRAW);
  bindColor(R.dyn); gl.drawArrays(mode, 0, arr.length / 7);
}
function bindBlock(vb) {
  const gl = R.gl, p = R.pB, a = gl.getAttribLocation(p, 'aPos'), b = gl.getAttribLocation(p, 'aUV'), c = gl.getAttribLocation(p, 'aShade'), d = gl.getAttribLocation(p, 'aTint');
  gl.bindBuffer(gl.ARRAY_BUFFER, vb);
  gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 28, 0);
  gl.enableVertexAttribArray(b); gl.vertexAttribPointer(b, 2, gl.FLOAT, false, 28, 12);
  gl.enableVertexAttribArray(c); gl.vertexAttribPointer(c, 1, gl.FLOAT, false, 28, 20);
  gl.enableVertexAttribArray(d); gl.vertexAttribPointer(d, 1, gl.FLOAT, false, 28, 24);
}

/* box with optional limb swing, pushed as colored triangles */
const BOXF = [[1, 3, 7, 5, 0.75], [0, 4, 6, 2, 0.75], [2, 3, 7, 6, 1], [0, 1, 5, 4, 0.55], [4, 5, 7, 6, 0.88], [0, 1, 3, 2, 0.88]];
function pushBox(out, o) {
  const cs = Math.cos(o.ang || 0), sn = Math.sin(o.ang || 0), cy = Math.cos(o.yaw), sy = Math.sin(o.yaw), P = [];
  for (let i = 0; i < 8; i++) {
    const x = o.cx + (i & 1 ? o.hx : -o.hx), y = o.cy + (i & 2 ? o.hy : -o.hy), z = o.cz + (i & 4 ? o.hz : -o.hz);
    const qy = y - o.py, qz = z - o.pz, y2 = qy * cs - qz * sn + o.py, z2 = qy * sn + qz * cs + o.pz;
    P.push([x * cy + z2 * sy + o.ox, y2 + o.oy, -x * sy + z2 * cy + o.oz]);
  }
  const a = o.em ? -1 : 1;
  for (const f of BOXF) {
    const s = o.em ? 1 : f[4], r = o.col[0] * s, g = o.col[1] * s, b = o.col[2] * s;
    for (const k of [0, 1, 2, 0, 2, 3]) { const q = P[f[k]]; out.push(q[0], q[1], q[2], r, g, b, a); }
  }
}
/* textured box using the standard cuboid skin unwrap; sizes and pivots in 1/16 block units */
function pushTexBox(out, o) {
  const k = 1 / 16, hx = o.s[0] / 2, hy = o.s[1] / 2, hz = o.s[2] / 2, W = o.uvs[0], Hh = o.uvs[1], D = o.uvs[2], u = o.uv[0], v = o.uv[1];
  const cs = Math.cos(o.ang || 0), sn = Math.sin(o.ang || 0), cy = Math.cos(o.yaw), sy = Math.sin(o.yaw), P = [];
  for (let i = 0; i < 8; i++) {
    const x = (o.c[0] + (i & 1 ? hx : -hx)) * k, y = (o.c[1] + (i & 2 ? hy : -hy)) * k, z = (o.c[2] + (i & 4 ? hz : -hz)) * k;
    const py = o.pv * k, pz = o.c[2] * k, qy = y - py, qz = z - pz, y2 = qy * cs - qz * sn + py, z2 = qy * sn + qz * cs + pz;
    P.push([x * cy + z2 * sy + o.ox, y2 + o.oy, -x * sy + z2 * cy + o.oz]);
  }
  const rects = [[u + D + W, v + D, D, Hh], [u, v + D, D, Hh], [u + D, v, W, D], [u + D + W, v, W, D], [u + D, v + D, W, Hh], [u + 2 * D + W, v + D, W, Hh]];
  const shade = [2.75, 2.75, 3, 2.55, 2.88, 2.88];
  for (let f = 0; f < 6; f++) {
    const q = BOXF[f], r = rects[f], uvq = [];
    for (let j = 0; j < 4; j++) {
      const i = q[j], sx = i & 1 ? 1 : -1, sY = i & 2 ? 1 : -1, sz = i & 4 ? 1 : -1; let a, b;
      switch (f) {
        case 0: a = (1 - sz) / 2; b = (1 - sY) / 2; break; case 1: a = (1 + sz) / 2; b = (1 - sY) / 2; break;
        case 2: a = (1 + sx) / 2; b = (1 + sz) / 2; break; case 3: a = (1 + sx) / 2; b = (1 - sz) / 2; break;
        case 4: a = (1 + sx) / 2; b = (1 - sY) / 2; break; default: a = (1 - sx) / 2; b = (1 - sY) / 2;
      }
      uvq.push([(r[0] + 0.02 + a * (r[2] - 0.04)) / o.tw, (r[1] + 0.02 + b * (r[3] - 0.04)) / o.th]);
    }
    for (const j of [0, 1, 2, 0, 2, 3]) { const p = P[q[j]]; out.push(p[0], p[1], p[2], uvq[j][0], uvq[j][1], shade[f], 0); }
  }
}
function makeSkinTex(bmp) {
  const gl = R.gl, t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, bmp);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.bindTexture(gl.TEXTURE_2D, R.tex);
  return { tex: t, w: 64, h: Math.round(64 * bmp.height / bmp.width) };
}
function pushCube(out, x0, y0, z0, x1, y1, z1, r, g, b, a) {
  const q = (p, c) => out.push(p[0], p[1], p[2], r * c, g * c, b * c, a);
  const f = (A, Bq, C, D, c) => { q(A, c); q(Bq, c); q(C, c); q(A, c); q(C, c); q(D, c); };
  const v = (x, y, z) => [x, y, z];
  f(v(x1, y0, z0), v(x1, y1, z0), v(x1, y1, z1), v(x1, y0, z1), 0.8); f(v(x0, y0, z0), v(x0, y1, z0), v(x0, y1, z1), v(x0, y0, z1), 0.8);
  f(v(x0, y1, z0), v(x1, y1, z0), v(x1, y1, z1), v(x0, y1, z1), 1); f(v(x0, y0, z0), v(x1, y0, z0), v(x1, y0, z1), v(x0, y0, z1), 0.7);
  f(v(x0, y0, z1), v(x1, y0, z1), v(x1, y1, z1), v(x0, y1, z1), 0.9); f(v(x0, y0, z0), v(x1, y0, z0), v(x1, y1, z0), v(x0, y1, z0), 0.9);
}

/* clouds: blocky slabs drifting east */
const CLOUD_Y = 94, CS_ = 12, CR = 15;
const cloudOn = (cx, cz) => fbm2(cx * 0.16 + 31, cz * 0.16 + 77, 2) > 0.55;
function buildClouds(px, pz, driftCells, frac) {
  const out = [], pcx = Math.floor(px / CS_), pcz = Math.floor(pz / CS_), y0 = CLOUD_Y, y1 = CLOUD_Y + 4;
  for (let cz = pcz - CR; cz <= pcz + CR; cz++) for (let cx = pcx - CR; cx <= pcx + CR; cx++) {
    if (!cloudOn(cx - driftCells, cz)) continue;
    const x0 = cx * CS_ + frac, x1 = x0 + CS_, z0 = cz * CS_, z1 = z0 + CS_;
    const q = (a, b, c, d, s) => { for (const p of [a, b, c, a, c, d]) out.push(p[0], p[1], p[2], 1 * s, 1 * s, 1 * s, 0.88); };
    q([x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1], 1);
    q([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], 0.74);
    if (!cloudOn(cx + 1 - driftCells, cz)) q([x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1], 0.86);
    if (!cloudOn(cx - 1 - driftCells, cz)) q([x0, y0, z0], [x0, y1, z0], [x0, y1, z1], [x0, y0, z1], 0.86);
    if (!cloudOn(cx - driftCells, cz + 1)) q([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], 0.8);
    if (!cloudOn(cx - driftCells, cz - 1)) q([x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], 0.8);
  }
  const gl = R.gl; gl.bindBuffer(gl.ARRAY_BUFFER, R.cloudBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(out), gl.DYNAMIC_DRAW);
  R.cloudN = out.length / 7;
}

/* main frame renderer. cam {x,y,z,yaw,pitch}, env {day,night,sky[3],sun[3],fogEnd,time}, extra {mobs[], hl, brk, renderDist} */
function renderFrame(cam, env, extra) {
  const gl = R.gl, W = R.canvas.width, Hh = R.canvas.height;
  gl.viewport(0, 0, W, Hh);
  gl.clearColor(env.sky[0], env.sky[1], env.sky[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  const P = mat.persp(cam.fov, W / Hh, 0.1, 700);
  const Vr = mat.mul(mat.rx(-cam.pitch), mat.ry(-cam.yaw));
  const V = mat.mul(Vr, mat.tr(-cam.x, -cam.y, -cam.z));
  const VP = mat.mul(P, V), SVP = mat.mul(P, Vr);
  const fogRange = [env.fogEnd * 0.55, env.fogEnd];
  gl.enable(gl.BLEND); gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
  gl.useProgram(R.pC); const u = R.pC.u;
  gl.uniformMatrix4fv(u.uVP, false, SVP); gl.uniform1f(u.uTint, 1); gl.uniform3fv(u.uFog, env.sky); gl.uniform2f(u.uFogRange, 1e8, 1e9);
  if (env.night > 0.02) {
    gl.uniform1f(u.uAlpha, env.night); gl.uniform1f(u.uPt, Math.max(1.5, 2 * (window.devicePixelRatio || 1)));
    bindColor(R.starBuf); gl.drawArrays(gl.POINTS, 0, R.nStars);
  }
  gl.uniform1f(u.uAlpha, 1); gl.uniform1f(u.uPt, 1);
  const body = (dir, size, col, a) => {
    let rx = dir[2], rz = -dir[0], l = Math.hypot(rx, rz) || 1; rx /= l; rz /= l;
    // up vector = dir x right
    const upx = dir[1] * rz - dir[2] * 0, upy = dir[2] * rx - dir[0] * rz, upz = dir[0] * 0 - dir[1] * rx;
    const c = [dir[0] * 200, dir[1] * 200, dir[2] * 200], out = [];
    const p = (sx, sy) => [c[0] + rx * size * sx + upx * size * sy, c[1] + upy * size * sy, c[2] + rz * size * sx + upz * size * sy];
    for (const k of [[-1, -1], [1, -1], [1, 1], [-1, -1], [1, 1], [-1, 1]]) { const q = p(k[0], k[1]); out.push(q[0], q[1], q[2], col[0], col[1], col[2], -a); }
    drawDyn(out, gl.TRIANGLES);
  };
  const sd = env.sunDir, md = [-sd[0], -sd[1], -sd[2]];
  body(sd, 34, [1, 0.93, 0.55], 0.28); body(sd, 20, [1, 0.97, 0.75], 1);
  body(md, 16, [0.82, 0.88, 1], 1); body(md, 6, [0.62, 0.68, 0.85], 1);

  gl.enable(gl.DEPTH_TEST);
  const pl = frustumPlanes(VP), pcx = Math.floor(cam.x / 16), pcz = Math.floor(cam.z / 16), rd = extra.renderDist;
  gl.useProgram(R.pB); const b = R.pB.u;
  gl.uniformMatrix4fv(b.uVP, false, VP); gl.uniform1f(b.uDay, env.day); gl.uniform3fv(b.uFog, env.sky); gl.uniform2fv(b.uFogRange, fogRange); gl.uniform3fv(b.uTint, R.tintArr || new Float32Array([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]));
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, R.tex); gl.uniform1i(b.uTex, 0);
  const vis = []; let drawn = 0;
  for (const c of chunks.values()) {
    if (!c.mesh) continue; const dx = c.cx - pcx, dz = c.cz - pcz; if (dx * dx + dz * dz > rd * rd + 2) continue;
    if (!boxInFrustum(pl, c.cx * 16, 0, c.cz * 16, c.cx * 16 + 16, H, c.cz * 16 + 16)) continue;
    vis.push(c);
  }
  gl.disable(gl.BLEND); gl.uniform1f(b.uWater, 0);
  for (const c of vis) if (c.mesh.n) { gl.uniform3f(b.uOff, c.cx * 16, 0, c.cz * 16); bindBlock(c.mesh.vb); gl.drawArrays(gl.TRIANGLES, 0, c.mesh.n); drawn++; }
  extra.drawn = drawn;
  if (extra.tb) {
    gl.uniform3f(b.uOff, 0, 0, 0);
    for (const key in extra.tb) { const q = extra.tb[key]; if (!q.arr.length) continue; gl.bindTexture(gl.TEXTURE_2D, q.sk.tex); gl.bindBuffer(gl.ARRAY_BUFFER, R.dyn); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(q.arr), gl.STREAM_DRAW); bindBlock(R.dyn); gl.drawArrays(gl.TRIANGLES, 0, q.arr.length / 7); }
    gl.bindTexture(gl.TEXTURE_2D, R.tex);
  }

  gl.enable(gl.BLEND); gl.useProgram(R.pC);
  gl.uniformMatrix4fv(u.uVP, false, VP); gl.uniform2fv(u.uFogRange, fogRange); gl.uniform1f(u.uAlpha, 1);
  gl.uniform1f(u.uTint, Math.max(0.3, env.day)); drawDyn(extra.mobs, gl.TRIANGLES);
  // clouds
  const off = env.time * 1.4, dc = Math.floor(off / CS_), frac = off - dc * CS_, key = (Math.floor(cam.x / CS_)) + ',' + Math.floor(cam.z / CS_) + ',' + dc;
  if (key !== R.cloudKey) { R.cloudKey = key; R.cloudFrac0 = frac; buildClouds(cam.x, cam.z, dc, frac); }
  gl.uniform1f(u.uTint, 0.28 + 0.72 * env.day); gl.uniform2f(u.uFogRange, 90, 250);
  gl.uniformMatrix4fv(u.uVP, false, mat.mul(VP, mat.tr(frac - R.cloudFrac0, 0, 0)));
  bindColor(R.cloudBuf); gl.drawArrays(gl.TRIANGLES, 0, R.cloudN);
  // water
  gl.useProgram(R.pB); gl.uniform1f(b.uWater, 1); gl.depthMask(false);
  for (const c of vis) if (c.mesh.nw) { gl.uniform3f(b.uOff, c.cx * 16, 0, c.cz * 16); bindBlock(c.mesh.vw); gl.drawArrays(gl.TRIANGLES, 0, c.mesh.nw); }
  gl.depthMask(true);
  // target outline + crack overlay
  gl.useProgram(R.pC); gl.uniformMatrix4fv(u.uVP, false, VP); gl.uniform2f(u.uFogRange, 1e8, 1e9); gl.uniform1f(u.uTint, 1);
  if (extra.hl) {
    const h = extra.hl, e = 0.004, x0 = h.x - e, y0 = h.y - e, z0 = h.z - e, x1 = h.x + 1 + e, y1 = h.y + 1 + e, z1 = h.z + 1 + e, ln = [];
    const L = (a, bb) => ln.push(a[0], a[1], a[2], 0, 0, 0, -0.85, bb[0], bb[1], bb[2], 0, 0, 0, -0.85);
    const c8 = []; for (let i = 0; i < 8; i++) c8.push([i & 1 ? x1 : x0, i & 2 ? y1 : y0, i & 4 ? z1 : z0]);
    for (const [i, j] of [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]]) L(c8[i], c8[j]);
    drawDyn(ln, gl.LINES);
    if (extra.brk > 0.02) { const o = [], e2 = 0.006; pushCube(o, h.x - e2, h.y - e2, h.z - e2, h.x + 1 + e2, h.y + 1 + e2, h.z + 1 + e2, 0, 0, 0, Math.min(0.65, extra.brk * 0.7)); drawDyn(o, gl.TRIANGLES); }
  }
}
