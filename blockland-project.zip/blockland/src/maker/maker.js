/* ===== Texture Lab. Uses TILES, SKINS, makeAtlas, makeZip, expandFiles from the shared sources. ===== */
const $ = id => document.getElementById(id);
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
const STORE = 'blockland-texlab-v1';

/* ---------- default art ---------- */
const atlas = makeAtlas();
const slots = {}; // key -> { key, label, cat, w, h, canvas, def (ImageData), tint, mod }
for (const t of TILES) {
  const c = mk(16, 16); c.getContext('2d').drawImage(atlas, (t.t % 16) * 16, Math.floor(t.t / 16) * 16, 16, 16, 0, 0, 16, 16);
  slots[t.name] = { key: t.name, label: t.label, cat: t.cat, w: 16, h: 16, canvas: c, tint: t.tint, tile: t, mod: false };
}
function faceRects(p) {
  const [W, H, D] = p.uvs || p.s, u = p.uv[0], v = p.uv[1];
  return [['top', u + D, v, W, D], ['bottom', u + D + W, v, W, D], ['right', u, v + D, D, H], ['front', u + D, v + D, W, H], ['left', u + D + W, v + D, D, H], ['back', u + 2 * D + W, v + D, W, H]];
}
const shadeCol = (c, k) => 'rgb(' + c.map(v => Math.round(Math.min(1, v * k) * 255)).join(',') + ')';
for (const key in SKINS) {
  const S = SKINS[key], c = mk(S.w, S.h), g = c.getContext('2d'), fur = key === 'sheep_fur';
  for (const p of (fur ? SKINS.sheep.parts : S.parts)) {
    if (!!p.fur !== fur) continue;
    for (const r of faceRects(p)) { g.fillStyle = shadeCol(p.col, r[0] === 'top' ? 1 : r[0] === 'bottom' ? 0.6 : 0.82); g.fillRect(r[1], r[2], r[3], r[4]); }
  }
  slots['skin:' + key] = { key: 'skin:' + key, label: S.label, cat: 'Mobs', w: S.w, h: S.h, canvas: c, skin: key, mod: false };
}
for (const k in slots) slots[k].def = slots[k].canvas.getContext('2d').getImageData(0, 0, slots[k].w, slots[k].h);

/* ---------- state ---------- */
const tint = { grass: TINT_DEFAULT.grass[0], foliage: TINT_DEFAULT.foliage[0] };
let cur = slots.grass_top, tool = 'pencil', recent = [], undo = new Map(), tab = 'Blocks';
let saveT = 0;
try {
  const s = JSON.parse(localStorage.getItem(STORE) || 'null');
  if (s) { if (s.tint) Object.assign(tint, s.tint); recent = s.recent || []; for (const k in (s.slots || {})) if (slots[k]) { const im = new Image(); im.onload = () => { const c = slots[k].canvas.getContext('2d'); c.clearRect(0, 0, slots[k].w, slots[k].h); c.drawImage(im, 0, 0); slots[k].mod = true; redrawThumb(slots[k]); if (cur === slots[k]) draw(); }; im.src = s.slots[k]; } }
} catch (e) { }
function persist() {
  clearTimeout(saveT); saveT = setTimeout(() => {
    try { const o = {}; for (const k in slots) if (slots[k].mod) o[k] = slots[k].canvas.toDataURL(); localStorage.setItem(STORE, JSON.stringify({ tint, recent, slots: o })); } catch (e) { }
  }, 500);
}
let toastT = 0;
function toast(m) { const t = $('toast'); t.textContent = m; t.style.opacity = 1; clearTimeout(toastT); toastT = setTimeout(() => t.style.opacity = 0, 1800); }

/* ---------- list ---------- */
const thumbs = {};
function redrawThumb(s) { const c = thumbs[s.key]; if (!c) return; const g = c.getContext('2d'); g.clearRect(0, 0, 32, 32); g.imageSmoothingEnabled = false; const sc = Math.min(32 / s.w, 32 / s.h); g.drawImage(s.canvas, 0, 0, s.w * sc, s.h * sc); const b = c.parentNode; if (b) b.classList.toggle('mod', s.mod); }
function buildList() {
  const L = $('list'); L.innerHTML = ''; let lastCat = '';
  for (const k in slots) {
    const s = slots[k], isMob = s.cat === 'Mobs'; if ((tab === 'Mobs') !== isMob) continue;
    if (s.cat !== lastCat) { lastCat = s.cat; const h = document.createElement('div'); h.className = 'cat'; h.textContent = s.cat; L.appendChild(h); }
    const b = document.createElement('button'); b.className = 'slotbtn' + (s === cur ? ' sel' : '') + (s.mod ? ' mod' : '');
    const c = mk(32, 32); thumbs[k] = c; b.appendChild(c);
    const sp = document.createElement('span'); sp.textContent = s.label; b.appendChild(sp); b.appendChild(document.createElement('i'));
    b.onclick = () => select(s); L.appendChild(b); redrawThumb(s);
  }
}
function select(s) { cur = s; buildList(); layout(); $('slotTitle').textContent = s.label; $('slotInfo').textContent = s.w + ' x ' + s.h + (s.tile ? '   file: ' + s.tile.name + '.png' : '   file: ' + s.skin + '.png'); $('tintRow').hidden = !s.tint; $('guideRow').hidden = !s.skin; draw(); previews(); }
function setTab(t) { tab = t; $('tabBlocks').classList.toggle('on', t === 'Blocks'); $('tabMobs').classList.toggle('on', t === 'Mobs'); const first = Object.values(slots).find(s => (s.cat === 'Mobs') === (t === 'Mobs')); select(first); }
$('tabBlocks').onclick = () => setTab('Blocks'); $('tabMobs').onclick = () => setTab('Mobs');

/* ---------- editor canvas ---------- */
const cv = $('cv'), cg = cv.getContext('2d');
let scale = 20;
function layout() {
  const avail = Math.max(240, ($('stage').clientWidth || 600) - 28);
  scale = Math.max(4, Math.min(24, Math.floor(avail / cur.w))); cv.width = cur.w * scale; cv.height = cur.h * scale;
}
function tinted(s) {
  const c = mk(s.w, s.h), g = c.getContext('2d'); g.drawImage(s.canvas, 0, 0);
  if (s.tint) { g.globalCompositeOperation = 'multiply'; g.fillStyle = tint[s.tint]; g.fillRect(0, 0, s.w, s.h); g.globalCompositeOperation = 'destination-in'; g.drawImage(s.canvas, 0, 0); }
  return c;
}
function draw() {
  const s = cur, W = cv.width, Hh = cv.height; cg.imageSmoothingEnabled = false; cg.clearRect(0, 0, W, Hh);
  const cs = Math.max(4, scale / 2);
  for (let y = 0; y < Hh; y += cs) for (let x = 0; x < W; x += cs) { cg.fillStyle = ((x / cs + y / cs) & 1) ? '#2a2a2a' : '#1c1c1c'; cg.fillRect(x, y, cs, cs); }
  cg.drawImage(s.tint && $('optTint').checked ? tinted(s) : s.canvas, 0, 0, W, Hh);
  if (scale >= 8) { cg.strokeStyle = 'rgba(255,255,255,.10)'; cg.lineWidth = 1; cg.beginPath(); for (let x = 0; x <= s.w; x++) { cg.moveTo(x * scale + .5, 0); cg.lineTo(x * scale + .5, Hh); } for (let y = 0; y <= s.h; y++) { cg.moveTo(0, y * scale + .5); cg.lineTo(W, y * scale + .5); } cg.stroke(); }
  if (s.skin && $('optGuide').checked) {
    const parts = s.skin === 'sheep_fur' ? SKINS.sheep.parts.filter(p => p.fur) : SKINS[s.skin].parts.filter(p => !(s.skin === 'sheep' && p.fur));
    const seen = new Set(); cg.font = '600 ' + Math.max(9, Math.floor(scale * 0.9)) + 'px monospace'; cg.textBaseline = 'top';
    for (const p of parts) { if (p.dup) continue; for (const r of faceRects(p)) { const key = r.join(','); if (seen.has(key)) continue; seen.add(key);
      cg.strokeStyle = 'rgba(166,217,79,.9)'; cg.lineWidth = 1; cg.strokeRect(r[1] * scale + .5, r[2] * scale + .5, r[3] * scale - 1, r[4] * scale - 1);
      if (r[3] * scale > 60 && r[4] * scale > 14) { cg.fillStyle = 'rgba(0,0,0,.6)'; const label = p.n + ' ' + r[0]; const tw = cg.measureText(label).width; cg.fillRect(r[1] * scale + 2, r[2] * scale + 2, Math.min(tw + 6, r[3] * scale - 4), scale * 1.1); cg.fillStyle = '#fff'; cg.fillText(label, r[1] * scale + 5, r[2] * scale + 3, r[3] * scale - 8); } } }
  }
}
/* paint */
const colorRGBA = () => { const h = $('col').value, a = +$('alpha').value / 100; return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16), Math.round(a * 255)]; };
function ctx() { return cur.canvas.getContext('2d', { willReadFrequently: true }); }
function pushUndo() { const l = undo.get(cur.key) || []; l.push(ctx().getImageData(0, 0, cur.w, cur.h)); if (l.length > 40) l.shift(); undo.set(cur.key, l); }
function setPx(x, y, rgba) { if (x < 0 || y < 0 || x >= cur.w || y >= cur.h) return; const g = ctx(), id = g.createImageData(1, 1); id.data.set(rgba); g.putImageData(id, x, y); }
function plot(x, y) {
  const erase = tool === 'eraser', c = erase ? [0, 0, 0, 0] : colorRGBA();
  setPx(x, y, c); if ($('optMirror').checked) setPx(cur.w - 1 - x, y, c);
}
function flood(x, y) {
  const g = ctx(), id = g.getImageData(0, 0, cur.w, cur.h), d = id.data, W = cur.w, c = colorRGBA(), i0 = (y * W + x) * 4, t = [d[i0], d[i0 + 1], d[i0 + 2], d[i0 + 3]];
  if (t.every((v, i) => v === c[i])) return; const st = [[x, y]];
  while (st.length) { const [px, py] = st.pop(); if (px < 0 || py < 0 || px >= W || py >= cur.h) continue; const i = (py * W + px) * 4; if (d[i] !== t[0] || d[i + 1] !== t[1] || d[i + 2] !== t[2] || d[i + 3] !== t[3]) continue; d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = c[3]; st.push([px + 1, py], [px - 1, py], [px, py + 1], [px, py - 1]); }
  g.putImageData(id, 0, 0);
}
function pickAt(x, y) { if (x < 0 || y < 0 || x >= cur.w || y >= cur.h) return; const d = ctx().getImageData(x, y, 1, 1).data; if (d[3] === 0) return; $('col').value = '#' + [d[0], d[1], d[2]].map(v => v.toString(16).padStart(2, '0')).join(''); $('alpha').value = Math.round(d[3] / 2.55); }
function touched() { cur.mod = true; redrawThumb(cur); draw(); previews(); persist(); }
let drawing = false, lx = 0, ly = 0;
const cell = e => { const r = cv.getBoundingClientRect(); return [Math.floor((e.clientX - r.left) * (cv.width / r.width) / scale), Math.floor((e.clientY - r.top) * (cv.height / r.height) / scale)]; };
function line(x0, y0, x1, y1) { const dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1; let err = dx - dy; for (; ;) { plot(x0, y0); if (x0 === x1 && y0 === y1) break; const e2 = 2 * err; if (e2 > -dy) { err -= dy; x0 += sx; } if (e2 < dx) { err += dx; y0 += sy; } } }
cv.addEventListener('pointerdown', e => {
  e.preventDefault(); const [x, y] = cell(e);
  if (tool === 'pick') { pickAt(x, y); return; }
  pushUndo(); cv.setPointerCapture(e.pointerId);
  if (tool === 'fill') { flood(x, y); addRecent(); touched(); return; }
  drawing = true; lx = x; ly = y; plot(x, y); touched();
});
cv.addEventListener('pointermove', e => { if (!drawing) return; const [x, y] = cell(e); if (x === lx && y === ly) return; line(lx, ly, x, y); lx = x; ly = y; touched(); });
const endDraw = () => { if (drawing) addRecent(); drawing = false; };
cv.addEventListener('pointerup', endDraw); cv.addEventListener('pointercancel', endDraw);
function doUndo() { const l = undo.get(cur.key); if (!l || !l.length) return toast('Nothing to undo'); ctx().putImageData(l.pop(), 0, 0); touched(); }
$('btnUndo').onclick = doUndo;
window.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); doUndo(); } });
document.querySelectorAll('#tools [data-tool]').forEach(b => b.onclick = () => { tool = b.dataset.tool; document.querySelectorAll('#tools [data-tool]').forEach(x => x.classList.toggle('on', x === b)); });

/* swatches */
const BASE_SW = ['#000000', '#ffffff', '#7a7a7e', '#b0b0b4', '#7a563a', '#a8885a', '#c8b078', '#e0cf98', '#7cbd4a', '#4f9a2c', '#2e6a1e', '#3a7ad0', '#d04040', '#e8a030', '#f0e050', '#6a3ab0'];
function addRecent() { const h = $('col').value; if (recent[0] !== h) { recent = [h, ...recent.filter(x => x !== h)].slice(0, 12); drawSwatches(); persist(); } }
function drawSwatches() { const S = $('swatches'); S.innerHTML = ''; for (const h of [...recent, ...BASE_SW]) { const b = document.createElement('button'); b.className = 'sw'; b.style.background = h; b.title = h; b.setAttribute('aria-label', h); b.onclick = () => { $('col').value = h; }; S.appendChild(b); } }

/* transforms */
function xform(fn) { pushUndo(); const g = ctx(), id = g.getImageData(0, 0, cur.w, cur.h), out = g.createImageData(cur.w, cur.h); for (let y = 0; y < cur.h; y++) for (let x = 0; x < cur.w; x++) { const [sx, sy] = fn(x, y); const a = ((sy + cur.h) % cur.h * cur.w + (sx + cur.w) % cur.w) * 4, b = (y * cur.w + x) * 4; for (let k = 0; k < 4; k++) out.data[b + k] = id.data[a + k]; } g.putImageData(out, 0, 0); touched(); }
$('btnFlipH').onclick = () => xform((x, y) => [cur.w - 1 - x, y]); $('btnFlipV').onclick = () => xform((x, y) => [x, cur.h - 1 - y]);
$('btnL').onclick = () => xform((x, y) => [x + 1, y]); $('btnR').onclick = () => xform((x, y) => [x - 1, y]); $('btnU').onclick = () => xform((x, y) => [x, y + 1]); $('btnD').onclick = () => xform((x, y) => [x, y - 1]);
$('btnClear').onclick = () => { pushUndo(); ctx().clearRect(0, 0, cur.w, cur.h); touched(); };
$('btnReset').onclick = () => { pushUndo(); ctx().putImageData(cur.def, 0, 0); cur.mod = false; redrawThumb(cur); draw(); previews(); persist(); toast('Slot reset'); };
$('optTint').onchange = draw; $('optGuide').onchange = draw;

/* import / export */
async function loadInto(s, bmp, sx, sy, sw, sh) { pushUndo(); const g = s.canvas.getContext('2d'); g.imageSmoothingEnabled = false; g.clearRect(0, 0, s.w, s.h); g.drawImage(bmp, sx || 0, sy || 0, sw || bmp.width, sh || bmp.height, 0, 0, s.w, s.h); s.mod = true; redrawThumb(s); }
$('btnLoadSlot').onclick = () => $('fileSlot').click();
$('fileSlot').onchange = async e => { const f = e.target.files[0]; if (!f) return; try { const b = await createImageBitmap(f); await loadInto(cur, b, 0, 0, cur.skin ? b.width : b.width, cur.skin ? b.height : (cur.key === 'water_still' ? b.width : b.height)); draw(); previews(); persist(); } catch (er) { toast('That file is not a PNG image'); } e.target.value = ''; };
$('btnSaveSlot').onclick = () => cur.canvas.toBlob(b => download(b, (cur.tile ? cur.tile.name : cur.skin) + '.png'));
$('btnImport').onclick = () => $('fileImport').click();
const BLOCKMAP = {}; for (const t of TILES) { BLOCKMAP[t.name] = t.name; (t.alias || []).forEach(n => BLOCKMAP[n] = t.name); }
$('fileImport').onchange = async e => {
  const files = await expandFiles([...e.target.files]); let n = 0;
  for (const f of files) {
    if (/pack\.json$/i.test(f.name)) { try { const j = JSON.parse(await f.text()); if (j.tint) { Object.assign(tint, j.tint); $('tGrass').value = tint.grass; $('tFoliage').value = tint.foliage; } } catch (er) { } continue; }
    let b; try { b = await createImageBitmap(f); } catch (er) { continue; }
    const key = baseName(f);
    if (BLOCKMAP[key]) { const s = slots[BLOCKMAP[key]]; await loadInto(s, b, 0, 0, b.width, key === 'water_still' ? b.width : b.height); n++; }
    else if (slots['skin:' + key]) { const s = slots['skin:' + key], h = Math.round(b.width * s.h / s.w); await loadInto(s, b, 0, 0, b.width, Math.min(b.height, h)); n++; }
    else if (b.width === b.height && b.width >= 256 && b.width % 16 === 0) { const ts = b.width / 16; for (const t of TILES) if (CLASSIC[t.t] !== undefined) { const src = CLASSIC[t.t]; await loadInto(slots[t.name], b, (src % 16) * ts, Math.floor(src / 16) * ts, ts, ts); } n++; }
  }
  e.target.value = ''; toast(n ? n + ' file' + (n > 1 ? 's' : '') + ' imported' : 'No matching files. Use the names shown under each slot.'); buildList(); draw(); previews(); persist();
};
function download(blob, name) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }
$('btnExport').onclick = async () => {
  const all = $('optAll').checked, entries = [], list = Object.values(slots).filter(s => all || s.mod);
  if (!list.length) return toast('Nothing changed yet. Edit a texture or tick "include unchanged".');
  for (const s of list) {
    const blob = await new Promise(r => s.canvas.toBlob(r, 'image/png')), data = new Uint8Array(await blob.arrayBuffer());
    entries.push({ name: (s.skin ? 'entity/' + s.skin : (s.cat === 'Blocks' ? 'blocks/' : 'items/') + s.tile.name) + '.png', data });
  }
  entries.push({ name: 'pack.json', data: new TextEncoder().encode(JSON.stringify({ game: 'Blockland', tint }, null, 2)) });
  download(makeZip(entries), 'blockland-pack.zip'); toast('Exported ' + list.length + ' textures');
};

/* ---------- previews ---------- */
const CUBE = { grass_top: ['grass_top', 'grass'], grass_side: ['grass_top', 'grass'], grass_side_overlay: ['grass_top', 'grass'], log_oak: ['log_oak_top', 'log_oak'], log_oak_top: ['log_oak_top', 'log_oak'], crafting_table_top: ['crafting_table_top', 'crafting_table_side'], crafting_table_side: ['crafting_table_top', 'crafting_table_side'], furnace_front_off: ['furnace_top', 'furnace_front_off'], furnace_top: ['furnace_top', 'furnace_front_off'] };
function faceCanvas(name) { // composited, tinted 16x16 face
  if (name === 'grass') { const c = mk(16, 16), g = c.getContext('2d'); g.drawImage(slots.grass_side.canvas, 0, 0); g.drawImage(tinted(slots.grass_side_overlay), 0, 0); return c; }
  const s = slots[name]; return s.tint ? tinted(s) : s.canvas;
}
function previews() {
  if (cur.skin) { for (const id of ['pvOne', 'pvTile', 'pvCube']) { const c = $(id); c.getContext('2d').clearRect(0, 0, c.width, c.height); } const g = $('pvOne').getContext('2d'); g.imageSmoothingEnabled = false; g.drawImage(cur.canvas, 0, 0, 96, Math.min(96, 96 * cur.h / cur.w)); return; }
  const one = $('pvOne').getContext('2d'), til = $('pvTile').getContext('2d'); one.imageSmoothingEnabled = til.imageSmoothingEnabled = false; one.clearRect(0, 0, 96, 96); til.clearRect(0, 0, 96, 96);
  const f = cur.key === 'grass_side_overlay' ? faceCanvas('grass') : cur.tint ? tinted(cur) : cur.canvas;
  one.drawImage(f, 0, 0, 96, 96); for (let y = 0; y < 3; y++) for (let x = 0; x < 3; x++) til.drawImage(f, x * 32, y * 32, 32, 32);
  const cg2 = $('pvCube').getContext('2d'); cg2.imageSmoothingEnabled = false; cg2.clearRect(0, 0, 120, 112);
  const m = CUBE[cur.key] || [cur.key, cur.key], top = faceCanvas(m[0] === 'grass_top' ? 'grass_top' : m[0]), side = faceCanvas(m[1]), k = 3, cx = 60, yt = 6;
  const face = (img, a, b, c, d, e, f2, shade) => { cg2.save(); cg2.setTransform(a, b, c, d, e, f2); cg2.drawImage(img, 0, 0); if (shade) { cg2.fillStyle = 'rgba(0,0,0,' + shade + ')'; cg2.fillRect(0, 0, 16, 16); } cg2.restore(); };
  face(top, k, k * .5, -k, k * .5, cx, yt, 0); face(side, k, k * .5, 0, k, cx - 16 * k, yt + 8 * k, 0.28); face(side, k, -k * .5, 0, k, cx, yt + 16 * k, 0.45);
}
$('tGrass').oninput = e => { tint.grass = e.target.value; draw(); previews(); persist(); };
$('tFoliage').oninput = e => { tint.foliage = e.target.value; draw(); previews(); persist(); };
$('tGrass').value = tint.grass; $('tFoliage').value = tint.foliage;
window.addEventListener('resize', () => { layout(); draw(); });
drawSwatches(); setTab('Blocks');
