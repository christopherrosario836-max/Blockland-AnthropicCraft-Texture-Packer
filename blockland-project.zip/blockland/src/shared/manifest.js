/* ===== Shared manifest: the single source of truth for texture slots and mob skins.
   The game and the Texture Lab are both built from this file, so adding a slot here
   adds it to both. t = tile index in the 16x16-tile atlas. tint = biome colour layer. ===== */
const TILES = [
  { t: 0, name: 'grass_top', label: 'Grass top', cat: 'Blocks', tint: 'grass' },
  { t: 1, name: 'grass_side', label: 'Grass side (dirt part)', cat: 'Blocks' },
  { t: 25, name: 'grass_side_overlay', label: 'Grass side overlay', cat: 'Blocks', tint: 'grass' },
  { t: 2, name: 'dirt', label: 'Dirt', cat: 'Blocks' },
  { t: 3, name: 'stone', label: 'Stone', cat: 'Blocks' },
  { t: 4, name: 'sand', label: 'Sand', cat: 'Blocks' },
  { t: 5, name: 'log_oak', label: 'Log side', cat: 'Blocks' },
  { t: 6, name: 'log_oak_top', label: 'Log top', cat: 'Blocks' },
  { t: 7, name: 'leaves_oak', label: 'Leaves', cat: 'Blocks', tint: 'foliage' },
  { t: 8, name: 'planks_oak', label: 'Planks', cat: 'Blocks' },
  { t: 9, name: 'cobblestone', label: 'Cobblestone', cat: 'Blocks' },
  { t: 10, name: 'water_still', label: 'Water', cat: 'Blocks' },
  { t: 11, name: 'coal_ore', label: 'Coal ore', cat: 'Blocks' },
  { t: 12, name: 'bedrock', label: 'Bedrock', cat: 'Blocks' },
  { t: 13, name: 'glass', label: 'Glass', cat: 'Blocks' },
  { t: 15, name: 'iron_ore', label: 'Iron ore', cat: 'Blocks' },
  { t: 16, name: 'crafting_table_top', label: 'Crafting table top', cat: 'Blocks' },
  { t: 17, name: 'crafting_table_side', label: 'Crafting table side', cat: 'Blocks' },
  { t: 19, name: 'furnace_front_off', label: 'Furnace front', cat: 'Blocks' },
  { t: 20, name: 'furnace_top', label: 'Furnace top', cat: 'Blocks' },
  { t: 21, name: 'anvil_base', label: 'Anvil', cat: 'Blocks' },
  { t: 14, name: 'beef_raw', alias: ['porkchop_raw', 'mutton_raw'], label: 'Raw meat', cat: 'Items' },
  { t: 22, name: 'stick', label: 'Stick', cat: 'Items' },
  { t: 23, name: 'coal', label: 'Coal', cat: 'Items' },
  { t: 24, name: 'iron_ingot', label: 'Iron ingot', cat: 'Items' },
  { t: 28, name: 'wood_pickaxe', label: 'Wooden pickaxe', cat: 'Tools' }, { t: 29, name: 'stone_pickaxe', label: 'Stone pickaxe', cat: 'Tools' }, { t: 30, name: 'iron_pickaxe', label: 'Iron pickaxe', cat: 'Tools' },
  { t: 31, name: 'wood_axe', label: 'Wooden axe', cat: 'Tools' }, { t: 32, name: 'stone_axe', label: 'Stone axe', cat: 'Tools' }, { t: 33, name: 'iron_axe', label: 'Iron axe', cat: 'Tools' },
  { t: 34, name: 'wood_sword', label: 'Wooden sword', cat: 'Tools' }, { t: 35, name: 'stone_sword', label: 'Stone sword', cat: 'Tools' }, { t: 36, name: 'iron_sword', label: 'Iron sword', cat: 'Tools' },
  { t: 37, name: 'wood_shovel', label: 'Wooden shovel', cat: 'Tools' }, { t: 38, name: 'stone_shovel', label: 'Stone shovel', cat: 'Tools' }, { t: 39, name: 'iron_shovel', label: 'Iron shovel', cat: 'Tools' },
];
/* Classic 16-column terrain.png indices for loading a whole old-style atlas */
const CLASSIC = { 0: 0, 1: 3, 2: 2, 3: 1, 4: 18, 5: 20, 6: 21, 7: 52, 8: 4, 9: 16, 10: 205, 25: 38 };

/* Mob skins. Sizes are in 1/16 block pixels. c = centre (x right, y up, z forward), s = box size,
   uv = top-left of the box in the 64-wide skin, uvs = size used for the unwrap when different from s,
   pv = pivot height, a0 = fixed X rotation, leg = swing direction, fur = uses the fur skin, col = default colour. */
const H2 = Math.PI / 2;
const SKINS = {
  zombie: { w: 64, h: 64, label: 'Zombie', parts: [
    { n: 'Head', c: [0, 28, 0], s: [8, 8, 8], uv: [0, 0], pv: 28, col: [0.4, 0.64, 0.36] },
    { n: 'Body', c: [0, 18, 0], s: [8, 12, 4], uv: [16, 16], pv: 18, col: [0.2, 0.46, 0.62] },
    { n: 'Arm', c: [-6, 18, 0], s: [4, 12, 4], uv: [40, 16], pv: 24, a0: -H2, col: [0.4, 0.64, 0.36] }, { n: 'Arm', c: [6, 18, 0], s: [4, 12, 4], uv: [40, 16], pv: 24, a0: -H2, col: [0.4, 0.64, 0.36], dup: 1 },
    { n: 'Leg', c: [-2, 6, 0], s: [4, 12, 4], uv: [0, 16], pv: 12, leg: 1, col: [0.25, 0.23, 0.52] }, { n: 'Leg', c: [2, 6, 0], s: [4, 12, 4], uv: [0, 16], pv: 12, leg: -1, col: [0.25, 0.23, 0.52], dup: 1 }] },
  pig: { w: 64, h: 32, label: 'Pig', parts: [
    { n: 'Head', c: [0, 11, 11], s: [8, 8, 8], uv: [0, 0], pv: 11, col: [0.96, 0.66, 0.66] },
    { n: 'Snout', c: [0, 10, 15.5], s: [4, 3, 1], uv: [16, 16], pv: 10, col: [0.86, 0.5, 0.52] },
    { n: 'Body', c: [0, 10, 0], s: [10, 16, 8], uv: [28, 8], pv: 10, a0: -H2, col: [0.95, 0.62, 0.62] },
    { n: 'Leg', c: [-3, 3, 5], s: [4, 6, 4], uv: [0, 16], pv: 6, leg: 1, col: [0.88, 0.55, 0.56] }, { n: 'Leg', c: [3, 3, 5], s: [4, 6, 4], uv: [0, 16], pv: 6, leg: -1, col: [0.88, 0.55, 0.56], dup: 1 },
    { n: 'Leg', c: [-3, 3, -5], s: [4, 6, 4], uv: [0, 16], pv: 6, leg: -1, col: [0.88, 0.55, 0.56], dup: 1 }, { n: 'Leg', c: [3, 3, -5], s: [4, 6, 4], uv: [0, 16], pv: 6, leg: 1, col: [0.88, 0.55, 0.56], dup: 1 }] },
  sheep: { w: 64, h: 32, label: 'Sheep', parts: [
    { n: 'Head', c: [0, 19, 10], s: [6, 6, 8], uv: [0, 0], pv: 19, col: [0.4, 0.34, 0.3] },
    { n: 'Body (fur layer)', c: [0, 16, 0], s: [11.5, 19.5, 9.5], uvs: [8, 16, 6], uv: [28, 8], pv: 16, a0: -H2, fur: 1, col: [0.92, 0.92, 0.88] },
    { n: 'Leg', c: [-3, 6, 5], s: [4, 12, 4], uv: [0, 16], pv: 12, leg: 1, col: [0.4, 0.34, 0.3] }, { n: 'Leg', c: [3, 6, 5], s: [4, 12, 4], uv: [0, 16], pv: 12, leg: -1, col: [0.4, 0.34, 0.3], dup: 1 },
    { n: 'Leg', c: [-3, 6, -5], s: [4, 12, 4], uv: [0, 16], pv: 12, leg: -1, col: [0.4, 0.34, 0.3], dup: 1 }, { n: 'Leg', c: [3, 6, -5], s: [4, 12, 4], uv: [0, 16], pv: 12, leg: 1, col: [0.4, 0.34, 0.3], dup: 1 }] },
  sheep_fur: { w: 64, h: 32, label: 'Sheep fur', parts: [] },
};
/* Default tint colours for biome-coloured layers (lush end and dry end) */
const TINT_DEFAULT = { grass: ['#7cbd4a', '#b9b24a'], foliage: ['#4f9a2c', '#8c9a2c'] };
