/* Shared zip helpers (stored + deflate read, stored write). Used by the game and the Texture Lab. */
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(u8) { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC_T[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
/* entries: [{ name: 'blocks/dirt.png', data: Uint8Array }] -> Blob */
function makeZip(entries) {
  const enc = new TextEncoder(), parts = [], central = []; let off = 0;
  for (const e of entries) {
    const nm = enc.encode(e.name), crc = crc32(e.data), h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true); h.setUint16(10, 0, true); h.setUint16(12, 0x21, true);
    h.setUint32(14, crc, true); h.setUint32(18, e.data.length, true); h.setUint32(22, e.data.length, true); h.setUint16(26, nm.length, true); h.setUint16(28, 0, true);
    parts.push(h.buffer, nm, e.data);
    const c = new DataView(new ArrayBuffer(46));
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true); c.setUint16(12, 0, true); c.setUint16(14, 0x21, true);
    c.setUint32(16, crc, true); c.setUint32(20, e.data.length, true); c.setUint32(24, e.data.length, true); c.setUint16(28, nm.length, true); c.setUint32(42, off, true);
    central.push(c.buffer, nm); off += 30 + nm.length + e.data.length;
  }
  let csz = 0; for (let i = 0; i < central.length; i++) csz += central[i].byteLength !== undefined ? central[i].byteLength : central[i].length;
  const end = new DataView(new ArrayBuffer(22)); end.setUint32(0, 0x06054b50, true); end.setUint16(8, entries.length, true); end.setUint16(10, entries.length, true); end.setUint32(12, csz, true); end.setUint32(16, off, true);
  return new Blob([...parts, ...central, end.buffer], { type: 'application/zip' });
}
/* zip File -> [File] (png and json entries only) */
async function unzipFiles(file) {
  const buf = await file.arrayBuffer(), dv = new DataView(buf), out = [];
  let e = buf.byteLength - 22; while (e >= 0 && dv.getUint32(e, true) !== 0x06054b50) e--; if (e < 0) return out;
  let p = dv.getUint32(e + 16, true); const n = dv.getUint16(e + 10, true);
  for (let i = 0; i < n; i++) {
    const method = dv.getUint16(p + 10, true), csz = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true);
    const name = new TextDecoder().decode(new Uint8Array(buf, p + 46, nl)); p += 46 + nl + xl + cl;
    if (name.endsWith('/') || !/\.(png|json)$/i.test(name)) continue;
    const lo = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true); let data = new Uint8Array(buf, lo, csz);
    if (method === 8) { try { data = new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer()); } catch (er) { continue; } }
    else if (method !== 0) continue;
    out.push(new File([data], name.split('/').pop(), { type: /json$/i.test(name) ? 'application/json' : 'image/png' }));
  }
  return out;
}
async function expandFiles(list) { let out = []; for (const f of list) { if (/\.zip$/i.test(f.name)) out = out.concat(await unzipFiles(f)); else out.push(f); } return out; }
const baseName = f => f.name.toLowerCase().replace(/\.[a-z]+$/, '').replace(/[ -]\d+$/, '').replace(/\s+/g, '_');
