/* ---------- procedural texture atlas (original pixel art, generated at load) ---------- */
function makeAtlas() {
  const cv = document.createElement('canvas'); cv.width = cv.height = 256;
  const g = cv.getContext('2d'), img = g.createImageData(256, 256), d = img.data, rnd = mulberry32(90210);
  const clamp = v => v < 0 ? 0 : v > 255 ? 255 : v | 0;
  function fill(t, fn) {
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
      const c = fn(x, y), i = (((t / 16) | 0) * 16 + y) * 1024 + ((t % 16) * 16 + x) * 4;
      d[i] = clamp(c[0]); d[i + 1] = clamp(c[1]); d[i + 2] = clamp(c[2]); d[i + 3] = c[3] === undefined ? 255 : c[3];
    }
  }
  const jit = (b, v) => { const n = (rnd() - 0.5) * 2 * v; return [b[0] + n, b[1] + n, b[2] + n]; };
  fill(0, () => { const c = jit([232, 232, 232], 22); if (rnd() < 0.1) { c[0] -= 34; c[1] -= 34; c[2] -= 34; } return c; });
  fill(2, () => { let c = jit([122, 86, 58], 16); if (rnd() < 0.1) c = [c[0] - 28, c[1] - 22, c[2] - 16]; if (rnd() < 0.04) c = [150, 140, 130]; return c; });
  const depth = []; for (let x = 0; x < 16; x++) depth.push(3 + (rnd() < 0.45 ? 1 : 0) + (rnd() < 0.15 ? 1 : 0));
  fill(1, () => { let c = jit([122, 86, 58], 16); if (rnd() < 0.1) c = [c[0] - 28, c[1] - 22, c[2] - 16]; if (rnd() < 0.04) c = [150, 140, 130]; return c; });
  fill(25, (x, y) => { if (y >= depth[x]) return [0, 0, 0, 0]; const c = jit([232, 232, 232], 22); if (y === depth[x] - 1 && rnd() < 0.35) { c[0] -= 40; c[1] -= 40; c[2] -= 40; } return c; });
  fill(3, (x, y) => { const b = vnoise(x * 0.45 + 40, y * 0.45, 5) * 36; return jit([138 - b, 138 - b, 140 - b], 12); });
  fill(4, () => jit([222, 209, 152], 12));
  const streak = []; for (let x = 0; x < 16; x++) streak.push((rnd() - 0.5) * 30);
  fill(5, (x) => jit([104 + streak[x], 79 + streak[x] * 0.8, 48 + streak[x] * 0.5], 8));
  fill(6, (x, y) => { const r = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5)); if (r > 6.6) return jit([92, 68, 40], 6); const k = Math.floor(Math.hypot(x - 7.5, y - 7.5)) % 3; return jit(k === 0 ? [172, 138, 88] : k === 1 ? [150, 116, 70] : [162, 128, 80], 6); });
  fill(7, () => { if (rnd() < 0.17) return [0, 0, 0, 0]; const c = jit([196, 196, 196], 34); if (rnd() < 0.22) { c[0] -= 46; c[1] -= 46; c[2] -= 46; } return c; });
  fill(8, (x, y) => { const r = y >> 2, seam = (y & 3) === 3, vs = x === ((r & 1) ? 4 : 11); const c = jit([178, 140, 84], 9); return seam || vs ? [c[0] - 46, c[1] - 42, c[2] - 34] : c; });
  const pts = []; for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) pts.push([i * 4 + 2 + (rnd() - 0.5) * 3, j * 4 + 2 + (rnd() - 0.5) * 3, 120 + rnd() * 40]);
  fill(9, (x, y) => {
    let d1 = 99, d2 = 99, tone = 130;
    for (const p of pts) for (const ox of [-16, 0, 16]) for (const oy of [-16, 0, 16]) { const dd = Math.hypot(x - p[0] - ox, y - p[1] - oy); if (dd < d1) { d2 = d1; d1 = dd; tone = p[2]; } else if (dd < d2) d2 = dd; }
    if (d2 - d1 < 1.1) return [62, 62, 64];
    const n = (rnd() - 0.5) * 14; return [tone + n, tone + n, tone + 4 + n];
  });
  fill(10, (x, y) => { const w = vnoise(x * 0.5, y * 0.5, 8) * 40; const c = jit([36 + w * 0.3, 88 + w * 0.6, 196 + w * 0.4], 8); c[3] = 220; return c; });
  const blobs = []; for (let i = 0; i < 6; i++) blobs.push([2 + rnd() * 12, 2 + rnd() * 12, 1.2 + rnd() * 1.4]);
  fill(11, (x, y) => { for (const b of blobs) if (Math.hypot(x - b[0], y - b[1]) < b[2]) return jit([36, 36, 40], 10); const bn = vnoise(x * 0.45 + 40, y * 0.45, 5) * 36; return jit([138 - bn, 138 - bn, 140 - bn], 12); });
  fill(12, (x, y) => { const b = vnoise(x * 0.6, y * 0.6, 3) * 50; return jit([70 - b * 0.5, 70 - b * 0.5, 74 - b * 0.5], 16); });
  fill(13, (x, y) => { const edge = x === 0 || y === 0 || x === 15 || y === 15; if (edge) return [196, 228, 240, 235]; if ((x === 3 && y === 3) || (x === 4 && y === 4) || (x === 3 && y === 5) || (x === 5 && y === 3)) return [255, 255, 255, 190]; return [200, 235, 250, 40]; });
  const px = (t, pts, col) => { for (const p of pts) { if (p[0] < 0 || p[0] > 15 || p[1] < 0 || p[1] > 15) continue; const i = (((t / 16) | 0) * 16 + p[1]) * 1024 + ((t % 16) * 16 + p[0]) * 4; d[i] = col[0]; d[i + 1] = col[1]; d[i + 2] = col[2]; d[i + 3] = 255; } };
  const clr = t => { for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) d[(((t / 16) | 0) * 16 + y) * 1024 + ((t % 16) * 16 + x) * 4 + 3] = 0; };
  const stoneBase = (x, y) => { const b = vnoise(x * 0.45 + 40, y * 0.45, 5) * 36; return jit([138 - b, 138 - b, 140 - b], 12); };
  fill(15, (x, y) => { for (const b of blobs) if (Math.hypot(x - b[0], y - b[1]) < b[2]) return jit([214, 168, 140], 10); return stoneBase(x, y); });
  fill(16, (x, y) => { const c = jit([178, 140, 84], 9); if (x % 5 === 0 || y % 5 === 0) return [c[0] - 70, c[1] - 62, c[2] - 50]; return c; });
  fill(17, (x, y) => { const c = jit([160, 122, 70], 9); if (y < 3) return jit([120, 88, 50], 6); if ((x > 2 && x < 7 && y > 5 && y < 12) || (x > 8 && x < 13 && y > 5 && y < 9)) return jit([92, 72, 50], 8); return c; });
  fill(19, (x, y) => { if (x > 3 && x < 12 && y > 5 && y < 13) return y > 10 ? jit([232, 128, 40], 16) : jit([26, 26, 28], 6); if (x > 2 && x < 13 && y > 4 && y < 14) return [70, 70, 74]; return stoneBase(x, y); });
  fill(20, (x, y) => (x === 0 || y === 0 || x === 15 || y === 15) ? [92, 92, 96] : stoneBase(x, y));
  fill(21, (x, y) => { const c = jit([62, 62, 70], 8); if (y < 3) return jit([108, 108, 118], 8); if (x > 4 && x < 11 && y > 4 && y < 12) return jit([46, 46, 52], 6); return c; });
  const HC = [[150, 112, 62], [140, 140, 144], [226, 226, 232]], HANDLE = [112, 80, 44];
  const handle = (t, a) => { const pts = []; for (let i = a; i < 12; i++) pts.push([i, 15 - i]); px(t, pts, HANDLE); };
  fill(22, () => [0, 0, 0, 0]); handle(22, 1); px(22, [[3, 12], [4, 11], [5, 10], [6, 9], [7, 8], [8, 7], [9, 6], [10, 5], [11, 4], [12, 3]], HANDLE);
  fill(23, (x, y) => { const dx = x - 7.5, dy = y - 8; if (dx * dx / 30 + dy * dy / 24 > 1) return [0, 0, 0, 0]; return jit([34, 34, 38], 10); });
  fill(24, (x, y) => { const sx = x - y * 0.4; if (y < 5 || y > 11 || x < 3 || x > 13 || sx < 1 || sx > 11) return [0, 0, 0, 0]; return y < 7 ? [240, 240, 244] : jit([206, 206, 212], 8); });
  for (let tier = 0; tier < 3; tier++) {
    const hc = HC[tier], lt = hc.map(v => Math.min(255, v + 30));
    for (let k = 0; k < 4; k++) {
      const t = 28 + k * 3 + tier; fill(t, () => [0, 0, 0, 0]);
      if (k === 2) { const bl = []; for (let i = 5; i < 15; i++) { bl.push([i, 15 - i]); bl.push([i - 1, 15 - i]); } px(t, bl, hc); px(t, [[7, 7], [8, 6], [9, 5], [10, 4]], lt); px(t, [[3, 8], [4, 9], [5, 10], [6, 11], [7, 12], [4, 8], [6, 10]], HANDLE); handle(t, 1); px(t, [[3, 12], [2, 13]], HANDLE); continue;
      }
      handle(t, 1);
      if (k === 0) px(t, [[5, 4], [6, 3], [7, 2], [8, 2], [9, 2], [10, 3], [11, 4], [12, 5], [12, 6], [4, 5], [4, 6], [5, 5], [6, 4], [11, 5]], hc);
      if (k === 1) px(t, [[8, 2], [9, 2], [10, 2], [8, 3], [9, 3], [10, 3], [11, 3], [9, 4], [10, 4], [11, 4], [12, 4], [10, 5], [11, 5], [8, 4], [7, 3]], hc);
      if (k === 3) px(t, [[11, 1], [12, 1], [10, 2], [11, 2], [12, 2], [13, 2], [10, 3], [11, 3], [12, 3], [13, 3], [11, 4], [12, 4], [9, 4]], hc);
    }
  }
  fill(14, (x, y) => { const dx = x - 7.5, dy = y - 8; if (dx * dx / 42 + dy * dy / 26 > 1) return [0, 0, 0, 0]; if (x > 11 && y < 6 && dx * dx / 4 + (dy + 4) * (dy + 4) / 4 < 2) return [235, 230, 215]; return jit(dy < -1 ? [200, 90, 90] : [225, 130, 120], 14); });
  g.putImageData(img, 0, 0);
  return cv;
}

