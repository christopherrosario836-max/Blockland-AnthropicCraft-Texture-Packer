#!/usr/bin/env python3
"""Builds both single-file apps from src/. Run: python3 build.py
Game  -> docs/index.html
Maker -> docs/maker/index.html
Both include src/shared/manifest.js, so adding a texture slot or mob skin there updates both."""
import os
R = os.path.dirname(os.path.abspath(__file__))
def read(*p):
    with open(os.path.join(R, 'src', *p), encoding='utf-8') as f: return f.read()
def write(path, text):
    p = os.path.join(R, *path.split('/')); os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f: f.write(text)
game_js = '\n'.join(read(*p.split('/')) for p in ['game/consts.js', 'shared/noise.js', 'game/world.js', 'shared/manifest.js', 'shared/zip.js', 'shared/art.js', 'game/render.js', 'game/game.js'])
write('docs/index.html', read('game', 'head.html') + '\n<script>\n' + game_js + '\n</script>\n')
if os.path.exists(os.path.join(R, 'src', 'maker', 'maker.html')):
    js = '\n'.join(read(*p.split('/')) for p in ['shared/noise.js', 'shared/manifest.js', 'shared/zip.js', 'shared/art.js', 'maker/maker.js'])
    write('docs/maker/index.html', read('maker', 'maker.html').replace('/*__SCRIPT__*/', js))
write('docs/.nojekyll', '')
print('built')
