# Blockland and Texture Lab

A voxel sandbox and the texture editor that goes with it, built from the same source files.

- Game: `docs/index.html`
- Texture Lab: `docs/maker/index.html` (served at `/maker/`)

## How they stay in sync

`src/shared/manifest.js` lists every texture slot (blocks, items, tools) and every mob skin layout.
Both apps are built from it. To add a new block texture or mob skin:

1. Add an entry to `TILES` or `SKINS` in `src/shared/manifest.js`.
2. Draw its default art in `src/shared/art.js` (blocks and items only).
3. Use the tile or skin in the game (`src/game/`).
4. Run `python3 build.py`.

The new slot then shows up in the Lab's list, the export, and the game's pack loader with no extra work.

## Build

    python3 build.py

No dependencies. It writes `docs/index.html` and `docs/maker/index.html`.

## Publish on GitHub Pages

Option A (no setup beyond one setting): commit the `docs/` folder, then in the repository go to
Settings > Pages and choose "Deploy from a branch", branch `main`, folder `/docs`.

Option B (rebuilds on every push): in Settings > Pages choose "GitHub Actions". The workflow in
`.github/workflows/pages.yml` runs `build.py` and deploys, so you only need to push source changes.

## Making a pack

1. Open the Texture Lab, paint textures, press Export pack. You get `blockland-pack.zip`.
2. In the game menu open Texture packs and pick the zip under Blocks and items, and again under Mobs and entities.

The zip holds `blocks/`, `items/` and `entity/` PNGs named after the slots, plus `pack.json` with the grass and leaf colours.
The game also accepts loose PNGs and a classic 16-column `terrain.png`.

## Layout

    src/shared/   manifest, default art, noise, zip helpers (used by both apps)
    src/game/     engine, world generation, rendering, game logic, page shell
    src/maker/    Texture Lab page and script
    build.py      assembles docs/

Grass and leaf art is stored in grey. The game multiplies it by a biome colour that blends from dry to lush,
and grass sides are drawn as a dirt layer plus a tinted overlay layer (`grass_side` and `grass_side_overlay`).
